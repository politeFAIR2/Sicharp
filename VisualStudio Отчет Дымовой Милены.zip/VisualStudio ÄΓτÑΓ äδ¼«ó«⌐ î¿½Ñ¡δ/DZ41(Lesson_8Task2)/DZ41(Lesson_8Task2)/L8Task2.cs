﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ41_Lesson_8Task2_
{
    internal class L8Task2
    {
        static void Main(string[] args)
        {
            int[] arr = L8MyFunctions.FillRandomArray();
            L8MyFunctions.Print(arr);

            int counter;
            L8MyFunctions.FindEven(arr, out counter);
            Console.WriteLine($"\nКоличество четных: {counter}");
        }
    }
}
