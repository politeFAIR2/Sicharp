﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ41_Lesson_8Task2_
{
    internal class L8MyFunctions
    {
        public static int[] FillRandomArray()
        {
            int[] arr = new int[10];
            Random random = new Random();
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = random.Next(-10, 11);
            }
            return arr;
        }
        public static void Print(int[] arr)
        {
            Console.WriteLine("Массив:");
            foreach (int num in arr)
            {
                Console.Write($"{num} ");
            }
        }
        public static void FindEven(int[] arr, out int counter)
        {
            counter = 0;
            Console.WriteLine("\nЧетные элементы:");
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] % 2 == 0)
                {
                    Console.WriteLine($"{arr[i]}, index: {i}");
                    counter++;
                }
            }
        }
    }
}
