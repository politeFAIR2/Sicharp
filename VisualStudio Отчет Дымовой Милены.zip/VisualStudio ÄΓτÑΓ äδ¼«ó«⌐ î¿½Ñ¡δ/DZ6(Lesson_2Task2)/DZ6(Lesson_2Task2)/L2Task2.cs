﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ6_Lesson_2Task2_
{
    internal class L2Task2
    {
        static void Main(string[] args)
        {
            Console.Write("Введите число: ");
            int number = Int32.Parse(Console.ReadLine());
            int units = Math.Abs(number) % 10;
            int tens = Math.Abs(number) / 10;
            Console.WriteLine($"Результат: единицы {units}, десятки {tens}");
        }
    }
}
