﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ14_Lesson_3Task2_
{
    internal class L3Task2
    {
        static void Main(string[] args)
        {
            Console.Write("Последовательность: ");
            for (int i = 1; i <= 100; i++)
            {
                Console.Write($"{i} ");
            }
            for (int i = 99; i >= 1; i--)
            {
                Console.Write($"{i} ");
            }
        }
    }
}
