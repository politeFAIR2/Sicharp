﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ47_Lesson_10Task4_
{
    internal class L10Task4
    {
        static void Main(string[] args)
        {
            Console.Write("Введите количество строк: ");
            int rows = int.Parse(Console.ReadLine());
            Console.Write("Введите количество столбцов: ");
            int cols = int.Parse(Console.ReadLine());
            int[,] matrix = FillMatrix(rows, cols);
            Console.WriteLine("\nМассив:");
            PrintMatrix(matrix);
            int min, max;
            FindMinMaxArr(matrix, out min, out max);
            Console.WriteLine($"min = {min}, max = {max}");
        }
        static int[,] FillMatrix(int rows, int cols)
        {
            int[,] matrix = new int[rows, cols];
            Random rand = new Random();

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    matrix[i, j] = rand.Next(-15, 16);
                }
            }
            return matrix;
        }
        static void PrintMatrix(int[,] matrix)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write($"{matrix[i, j],4} ");
                }
                Console.WriteLine();
            }
        }
        private static void FindMinMaxArr(int[,] matrix, out int min, out int max)
        {
            min = int.MaxValue;
            max = int.MinValue;
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    if (matrix[i, j] < min)
                    {
                        min = matrix[i, j];
                    }
                    if (matrix[i, j] > max)
                    {
                        max = matrix[i, j];
                    }
                }
            }
        }
    }
}
