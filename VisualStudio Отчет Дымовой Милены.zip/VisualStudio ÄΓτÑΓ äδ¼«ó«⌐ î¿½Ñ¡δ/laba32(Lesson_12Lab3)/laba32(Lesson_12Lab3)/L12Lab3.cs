﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace laba32_Lesson_12Lab3_
{
    internal class L12Lab3
    {
        static void Main(string[] args)
        {
            string pattern = @"\s+";
            string replacement = " ";

            Debug.Assert(ReplaceSpaces(" Good day  !", pattern, replacement) == " Good day !");
            Debug.Assert(ReplaceSpaces("   Hello World   ", pattern, replacement) == " Hello World ");
            Debug.Assert(ReplaceSpaces("   ", pattern, replacement) == " ");
            Console.WriteLine("Тесты пройдены");
            string input = "Hello   World   ";
            Console.WriteLine($"Исходная строка: '{input}'");
            Console.WriteLine($"Результирующая строка: '{ReplaceSpaces(input, pattern, replacement)}'");
        }
        static string ReplaceSpaces(string input, string pattern, string replacement = " ")
        {
            Regex rgx = new Regex(pattern);
            string result = rgx.Replace(input, replacement);
            return result;
        }
    }
}
