﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba27_Lesson_11Lab1_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var firstName = "Дарья";
            Console.WriteLine(firstName);
            var lastName = "Кувшинкина";
            Console.WriteLine(lastName);
            //задание 2
            var fullName = firstName + " " + lastName;
            Console.WriteLine(fullName);
            //задание 3
            var myFullName = string.Format("Меня зовут {0} {1}", firstName, lastName);
            Console.WriteLine(myFullName);
            //задание 4
            var names = new string[3] { "Иван", "Елена", "Мария" };
            var formattedNames = string.Join(",", names);
            Console.WriteLine(formattedNames);
            //задание 5
            var text = @"Привет, Иван
Посмотри на путь к файлам
c:\folder1\folder2
c:\folder3\folder4";
            Console.WriteLine(text);
        }
    }
}
