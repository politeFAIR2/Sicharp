﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DOPZ_Lesson_10ExTask1_
{
    internal class L10ExTask1
    {
        static void Main(string[] args)
        {
            Console.Write("Введите количество строк: ");
            int M = int.Parse(Console.ReadLine());
            Console.Write("Введите количество столбцов: ");
            int N = int.Parse(Console.ReadLine());
            Console.Write("Введите значение множителя (аргумента): ");
            int X = int.Parse(Console.ReadLine());
            int[,] matrix = FillMatrix(M, N, X);
            Console.WriteLine($"Матрица {M}х{N}:");
            PrintMatrix(matrix);
        }
        static int[,] FillMatrix(int M, int N, int X)
        {
            int[,] matrix = new int[M, N];

            for (int i = 0; i < M; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    matrix[i, j] = (j + 1) * X;
                }
            }
            return matrix;
        }
        static void PrintMatrix(int[,] matrix)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write($"{matrix[i, j],4} ");
                }
                Console.WriteLine();
            }
        }
    }
}
