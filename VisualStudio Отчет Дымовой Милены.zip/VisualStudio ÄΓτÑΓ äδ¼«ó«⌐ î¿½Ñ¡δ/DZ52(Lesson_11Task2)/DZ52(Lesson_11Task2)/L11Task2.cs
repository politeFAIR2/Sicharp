﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ52_Lesson_11Task2_
{
    internal class L11Task2
    {
        static void Main(string[] args)
        {
            string s1 = "hello";
            string s2 = "hello sir";
            char c = 's';
            Console.WriteLine($"Результат 1: Строка '{s1}' содержит {c}: {ContainsChar(s1, c)}");
            Console.WriteLine($"Результат 2: Строка '{s1}' содержит {c}: {ContainsCharLoop(s1, c)}");
            Console.WriteLine();
            Console.WriteLine($"Результат 1: Строка '{s2}' содержит {c}: {ContainsChar(s2, c)}");
            Console.WriteLine($"Результат 2: Строка '{s2}' содержит {c}: {ContainsCharLoop(s2, c)}");
        }
        static bool ContainsChar(string s, char c)
        {
            return s.Contains(c);
        }
        static bool ContainsCharLoop(string s, char c)
        {
            bool contains = false;
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == c)
                {
                    contains = true;
                    break;
                }
            }
            return contains;
        }
    }
}
