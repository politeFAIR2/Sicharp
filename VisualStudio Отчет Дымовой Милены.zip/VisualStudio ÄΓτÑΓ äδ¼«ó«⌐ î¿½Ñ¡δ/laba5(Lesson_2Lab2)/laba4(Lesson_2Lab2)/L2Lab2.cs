﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba5_Lesson_2Lab2_
{
    internal class L2Lab2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Coffee sizes: 1=small 2=medium 3=large");
            Console.Write("Please enter your selection:");
            string str = Console.ReadLine();
            int price = 0;
            switch (str)
            {
                case "1":
                    price += 23;
                    break;
                case "2":
                    price += 50;
                    break;
                case "3":
                    price += 75;
                    break;
                default:
                    Console.WriteLine("Неверный выбор. Введите 1, 2 или 3.");
                    break;
            }
                    if (price != 0)
                    {
                        Console.WriteLine($"{price} руб.");
                    }
            }
        }
    }
