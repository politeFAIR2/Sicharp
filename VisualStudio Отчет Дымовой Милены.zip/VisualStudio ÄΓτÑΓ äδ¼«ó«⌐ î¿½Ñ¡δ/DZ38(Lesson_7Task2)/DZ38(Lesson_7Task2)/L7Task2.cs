﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ38_Lesson_7Task2_
{
    internal class L7Task2
    {
        static void Main(string[] args)
        {
            int[] arr = GenerateArray();
            PrintArray(arr);
            Console.Write("Введите искомое значение: ");
            int n = int.Parse(Console.ReadLine());

            bool found = FindN(arr, n);
            Console.WriteLine(found ? "да" : "нет");
        }
        static int[] GenerateArray()
        {
            int[] arr = new int[15];
            Random random = new Random();
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = random.Next(1, 11);
            }
            return arr;
        }
        static void PrintArray(int[] arr)
        {
            Console.WriteLine("Массив:");
            foreach (int num in arr)
            {
                Console.Write($"{num} ");
            }
            Console.WriteLine();
        }
        static bool FindN(int[] arr, int n)
        {
            bool found = false;
            int index = -1;
            foreach (int num in arr)
            {
                if (num == n)
                {
                    found = true;
                    index = Array.IndexOf(arr, num);
                    Console.WriteLine($"Элемент {n} найден под индексом {index}");
                    break;
                }
            }
            return found;
        }
    }
}
