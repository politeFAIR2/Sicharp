﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba25_Lesson_10Lab3_
{
    internal class L10Lab3
    {
        static void Main(string[] args)
        {
            int[,] matrix = new int[3, 4];
            FillMatrix(matrix);
            Console.WriteLine("Матрица 3 x 4: ");
            PrintMatrix(matrix);
            Console.WriteLine("Введите номера столбцов для обмена (первый столбец - 0-й:)");
            int col1 = int.Parse(Console.ReadLine());
            int col2 = int.Parse(Console.ReadLine());
            ChangeColumns(matrix, col1, col2);
            Console.WriteLine("The resulting matrix:");
            PrintMatrix(matrix);
        }
        static void FillMatrix(int[,] matrix, int minValue = -10, int maxValue = 10)
        {
            Random rand = new Random();
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    matrix[i, j] = rand.Next(minValue, maxValue);
                }
            }
        }
        static void PrintMatrix(int[,] m)
        {
            for (int i = 0; i < m.GetLength(0); i++)
            {
                for (int j = 0; j < m.GetLength(1); j++)
                {
                    Console.Write(m[i, j].ToString().PadLeft(4));
                }
                Console.WriteLine();
            }
        }
        static void ChangeColumns(int[,] matrix, int col1, int col2)
        {
            System.Diagnostics.Debug.Assert((col1 < matrix.GetLength(1)) && (col2 < matrix.GetLength(1)), "указанный номер столбца выходит за границы размерности массива!");
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                int temp = matrix[i, col1];
                matrix[i, col1] = matrix[i, col2];
                matrix[i, col2] = temp;
            }
        }
    }
}