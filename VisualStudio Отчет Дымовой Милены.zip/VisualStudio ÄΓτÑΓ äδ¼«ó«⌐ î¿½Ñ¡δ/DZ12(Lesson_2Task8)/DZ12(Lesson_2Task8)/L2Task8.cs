﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ12_Lesson_2Task8_
{
    internal class L2Task8
    {
        static void Main(string[] args)
        {
            Console.Write("Введите число от 1 до 7: ");
            int dayNumber = int.Parse(Console.ReadLine());
            if (dayNumber >= 1 && dayNumber <= 7)
            {
                string dayName = "";
                switch (dayNumber)
                {
                    case 1: dayName = "понедельник"; break;
                    case 2: dayName = "вторник"; break;
                    case 3: dayName = "среда"; break;
                    case 4: dayName = "четверг"; break;
                    case 5: dayName = "пятница"; break;
                    case 6: dayName = "суббота"; break;
                    case 7: dayName = "воскресенье"; break;
                }
                Console.WriteLine($"Результат: {dayNumber}-й день недели - это {dayName}");
            }
            else
            {
                Console.WriteLine("Результат: такого дня недели нету, введите число от 1 до 7");
            }
        }
    }
}
