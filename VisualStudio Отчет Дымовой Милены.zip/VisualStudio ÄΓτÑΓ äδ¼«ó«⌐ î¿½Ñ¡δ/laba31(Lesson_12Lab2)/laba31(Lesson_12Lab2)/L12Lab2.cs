﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Diagnostics;

namespace laba31_Lesson_12Lab2_
{
    internal class L12Lab2
    {
        static void Main(string[] args)
        {
            Debug.Assert(CountZip("344113 34116 15 152566  14254124    12515 hello") == 2);
            Debug.Assert(CountZip("hello") == 0);
            Console.WriteLine("Тесты пройдены");
            string zipCode = "123: почтовый индекс 367824 севернее, чем 123712";
            Console.WriteLine($"строка содержит {CountZip(zipCode)} почтовых индекса");
        }
        static int CountZip(string zip)
        {
            var m = Regex.Matches(zip, @"\b\d{6}\b");
            return m.Count;
        }
    }
}
