﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DOPZ5_Lesson_10ExTask2_
{
    internal class L10ExTask2
    {
        static void Main(string[] args)
        {
            int[,] matrix1 = FillMatrix(3, 3);
            int[,] matrix2 = FillMatrix(3, 3);
            Console.WriteLine("Matrix 1:");
            PrintMatrix(matrix1);
            Console.WriteLine("\nMatrix 2:");
            PrintMatrix(matrix2);
            int[,] resultMatrix = SumMat(matrix1, matrix2);
            Console.WriteLine("\nResult matrix:");
            PrintMatrix(resultMatrix);
        }
        static int[,] FillMatrix(int rows, int cols)
        {
            int[,] matrix = new int[rows, cols];
            Random rand = new Random();

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    matrix[i, j] = rand.Next(-10, 11);
                }
            }
            return matrix;
        }
        static int[,] SumMat(int[,] a, int[,] b)
        {
            int[,] result = new int[a.GetLength(0), a.GetLength(1)];

            for (int i = 0; i < a.GetLength(0); i++)
            {
                for (int j = 0; j < a.GetLength(1); j++)
                {
                    result[i, j] = a[i, j] + b[i, j];
                }
            }
            return result;
        }
        static void PrintMatrix(int[,] matrix)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write($"{matrix[i, j],4} ");
                }
                Console.WriteLine();
            }
        }
    }
}
