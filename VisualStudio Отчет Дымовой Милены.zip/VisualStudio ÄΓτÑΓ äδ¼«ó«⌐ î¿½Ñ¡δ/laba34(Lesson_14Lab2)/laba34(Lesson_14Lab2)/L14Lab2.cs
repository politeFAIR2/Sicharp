﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.IO;

namespace laba34_Lesson_14Lab2_
{
    internal class L14Lab2
    {
        static void Main(string[] args)
        {
            string path = @"L01.dat";
            int N = 0;
            while (N <= 0)
            {
                Write("Введите число N (N > 0): ");
                if (int.TryParse(ReadLine(), out N) && N > 0)
                    break;
                else
                    WriteLine("Некорректное значение N. Попробуйте снова.");
            }
            PrintFileInRows(path, N);
            ReadKey();
        }
        static void PrintFileInRows(string path, int N = 10)
        {
            try
            {
                using (var fs = new FileStream(path, FileMode.Open))
                {
                    try
                    {
                        using (var br = new BinaryReader(fs))
                        {
                            if (br.PeekChar() == -1)
                            {
                                WriteLine("Пустой файл");
                                return;
                            }

                            int i = 0;
                            while (br.PeekChar() != -1)
                            {
                                Write($"{br.ReadInt32()} ");
                                i++;
                                if (i == N)
                                {
                                    WriteLine();
                                    i = 0;
                                }
                            }
                        }
                    }
                    catch (IOException e)
                    {
                        WriteLine($"Ошибка при работе с файлом: {e.Message}");
                    }
                }
            }
            catch (IOException e)
            {
                WriteLine($"Ошибка при открытии файла: {e.Message}");
            }
        }
    }
}
