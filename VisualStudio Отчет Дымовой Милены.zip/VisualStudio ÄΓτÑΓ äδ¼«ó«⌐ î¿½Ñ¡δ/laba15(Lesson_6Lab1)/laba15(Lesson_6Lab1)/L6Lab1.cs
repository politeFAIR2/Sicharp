﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace laba15_Lesson_6Lab1_
{
    internal class L6Lab1
    {
        enum Marks { very_bad, bad, satisfactory, good, excellent, noSuchMark };
        static void Main(string[] args)
        {
            int x = (int)Marks.satisfactory;
            Console.WriteLine($"And also the characteristic satiisfactory is for: {x} mark");
            WriteLine("Введите отметку");
            int mark = int.Parse(ReadLine());
            Marks characteristic = Marks.very_bad;
            CheckMark(mark, ref characteristic);
            WriteLine($"The characteristic for {mark} is: {characteristic}");
        }
        static void CheckMark(int mark, ref Marks characteristic)
        {
            switch (mark)
            {
                case 1:
                    characteristic = Marks.very_bad;
                    break;
                case 2:
                    characteristic = Marks.bad;
                    break;
                case 3:
                    characteristic = Marks.satisfactory;
                    break;
                case 4:
                    characteristic = Marks.good;
                    break;
                case 5:
                    characteristic = Marks.excellent;
                    break;
                default:
                    WriteLine("Invalid selection. Please select 1, 2. 3, 4 or 5.");
                    characteristic = Marks.noSuchMark;
                    break;
            }
        }
    }
}
