﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace laba21_Lesson_9Lab1_
{
    internal class L9Lab1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Целочисленный массив:");
                int[] arr1 = new int[] { 1, 6, 2, 7, 5 };
            arr1.PrintArr();
            Console.WriteLine("Масссив вещественных элементов:");
            double[] arr2 = { 1.2, 6.4, 2.1, 7.5 };
            arr2.PrintArr();

        }
    }
    public static class MyFuncs
    {
        public static void PrintArr <T>(this T[] arr)
        {
            foreach (var x in arr)
            {
                Console.Write($"{x}\n");
            }
        }
    }
}
