﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ53_Lesson_11Task3_
{
    internal class L11Task3
    {
        static void Main(string[] args)
        {
            string text1 = "hello world";
            string text2 = "my mammy is the best, ma-ma-ma";
            string pattern = "ma";
            Console.WriteLine($"Строка '{text1}' содержит {CountInText(text1, pattern)} вхождений '{pattern}'");
            Console.WriteLine("+++++++++++++++++++++");
            Console.WriteLine($"Строка '{text2}' содержит {CountInText(text2, pattern)} вхождений '{pattern}'");
        }
        static int CountInText(string text, string pattern)
        {
            int count = 0;
            for (int i = 0; i < text.Length - 1; i++)
            {
                if (text[i] == pattern[0] && text[i + 1] == pattern[1])
                {
                    count++;
                }
            }
            return count;
        }
    }
}
