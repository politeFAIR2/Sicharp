﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba28_Lesson_11Lab2_
{
    internal class L11Lab2
    {
        static void Main(string[] args)
        {
            string[] fullNames = new string[] { "Иван Иванов", "Петр Сидоров", "Михаил Никитин", "Ирина Александрова" };
            string[] firstNames = new string[fullNames.Length];
            for (var i = 0; i < fullNames.Length; i++)
            {
                var index = fullNames[i].IndexOf(' ');
            }
            for (var i = 0; i < fullNames.Length; i++)
            {
                var index = fullNames[i].IndexOf(' ');
                firstNames[i] = fullNames[i].Substring(0, index);
                Console.WriteLine("Привет, " + firstNames[i] + "!");
            }
            Console.WriteLine("Split method:");
            for (var i = 0; i < fullNames.Length; i++)
            {
                firstNames = fullNames[i].Split(' ');
                Console.WriteLine("Привет, " + firstNames[0] + "!");
            }
        }

    }
}
