﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ34_Lesson_6Task2_
{
    internal class L6Task2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите натуральные числа N и a:");
            int n = int.Parse(Console.ReadLine());
            int a = int.Parse(Console.ReadLine());
            GenerateSequence(n, a);
        }
        static void GenerateSequence(int n, int a)
        {
            for (int i = 0; i < n; i++)
            {
                Console.Write($"{a + i} ");
            }
            Console.WriteLine();
        }
    }
}
