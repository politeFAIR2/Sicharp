﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ27_Lesson_5Task2_
{
    internal class L5Task2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите значения для трех сторон треугольника:");
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());
            int perimeter = Perimeter(a, b, c);
            Console.WriteLine($"Периметр: {perimeter}");
        }
        static int Perimeter(int a, int b, int c)
        {
            return a + b + c;
        }
    }
}
