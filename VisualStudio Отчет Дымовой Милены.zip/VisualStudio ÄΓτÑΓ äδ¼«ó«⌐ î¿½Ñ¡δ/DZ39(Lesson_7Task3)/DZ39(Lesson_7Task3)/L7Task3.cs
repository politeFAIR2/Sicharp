﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ39_Lesson_7Task3_
{
    internal class L7Task3
    {
        static void Main(string[] args)
        {
            double[] arr = GenerateArray();
            PrintArray(arr);
            Console.WriteLine("Суммы троек:");
            PrintSumOfTriples(arr);
        }
        static double[] GenerateArray()
        {
            double[] arr = new double[10];
            Random rand = new Random();
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = rand.NextDouble() * 10 - 5;
            }
            return arr;
        }
        static void PrintArray(double[] arr)
        {
            Console.Write("Массив: ");
            foreach (double num in arr)
            {
                Console.Write($"{num:F2} ");
            }
            Console.WriteLine();
        }
        static void PrintSumOfTriples(double[] arr)
        {
            for (int i = 1; i <= arr.Length - 2; i++)
            {
                double sum = arr[i - 1] + arr[i] + arr[i + 1];
                Console.WriteLine($"{sum:F2}");
            }
        }
    }
}
