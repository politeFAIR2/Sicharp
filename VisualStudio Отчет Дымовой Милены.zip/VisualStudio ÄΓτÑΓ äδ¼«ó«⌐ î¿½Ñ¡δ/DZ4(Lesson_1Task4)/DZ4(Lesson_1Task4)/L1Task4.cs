﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ4_Lesson_1Task4_
{
    internal class L1Task4
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите 4 числа:");
            int x1 = int.Parse(Console.ReadLine());
            int x2 = int.Parse(Console.ReadLine());
            int x3 = int.Parse(Console.ReadLine());
            int x4 = int.Parse(Console.ReadLine());
            int sumFirstTwo = x1 + x2;
            int sumLastTwo = x3 + x4;
            bool result = sumFirstTwo > sumLastTwo;
            Console.WriteLine($"Результат: {result}");
            Console.ReadKey();
        }
    }
}
