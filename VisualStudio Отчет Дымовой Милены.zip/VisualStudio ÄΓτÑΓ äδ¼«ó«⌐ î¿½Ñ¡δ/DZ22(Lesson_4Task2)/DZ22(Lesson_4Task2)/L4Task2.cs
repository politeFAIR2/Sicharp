﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ22_Lesson_4Task2_
{
    internal class L4Task2
    {
        static void Main(string[] args)
        {
            int counter1 = 15;
            Console.Write("While: ");
            while (counter1 >= 0)
            {
                Console.Write($"{counter1} ");
                counter1 -= 3;
            }
            Console.WriteLine();
            int counter2 = 15;
            Console.Write("Do..While: ");
            do
            {
                Console.Write($"{counter2} ");
                counter2 -= 3;
            } while (counter2 >= 0);
            Console.WriteLine();
        }
    }
}
