﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba22_Lesson_9Lab2_
{
    internal class L9Lab2
    {
        static void Main(string[] args)
        {
            var calculator = new Calculator();
            Console.WriteLine($"результат с двумя параметрами (1, 2): {calculator.Add(1, 2)}");
            Console.WriteLine($"результат с тремя параметрами (1, 2, 3): {calculator.Add(1, 2, 3)}");
            Console.WriteLine($"результат с массивом (1, 2, 3, 4, 5): {calculator.Add(new int[] { 1, 2, 3, 4, 5 })}");
        }
    }
}
