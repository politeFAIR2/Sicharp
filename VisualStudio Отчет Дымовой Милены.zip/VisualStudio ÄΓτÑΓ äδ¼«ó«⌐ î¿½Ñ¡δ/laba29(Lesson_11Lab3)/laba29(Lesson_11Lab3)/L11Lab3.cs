﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba29_Lesson_11Lab3_
{
    internal class L11Lab3
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите предложение:");
            StringBuilder sb = new StringBuilder(Console.ReadLine());
            ReverseString(sb);
            Console.WriteLine("Инвертированное предложение:");
            Console.WriteLine(sb);
        }
        static void ReverseString(StringBuilder sb)
        {
            char c;
            for (int i = 0, j = sb.Length - 1; i < j; i++, j--)
            {
                c = sb[i];
                sb[i] = sb[j];
                sb[j] = c;
            }
        }
    }
}
