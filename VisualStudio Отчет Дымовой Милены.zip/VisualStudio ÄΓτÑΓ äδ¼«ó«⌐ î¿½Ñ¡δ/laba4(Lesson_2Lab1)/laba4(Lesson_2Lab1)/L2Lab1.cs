﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba4_Lesson_2Lab1_
{
    internal class L2Lab1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число");
            int num = Int32.Parse(Console.ReadLine());
            if (num % 2 == 0)
            {
                Console.WriteLine("Введенное число четное.");
            }
            else
            {
                Console.WriteLine("Введенное число нечетное.");
                Console.ReadKey();
            }
        }
    }
}
