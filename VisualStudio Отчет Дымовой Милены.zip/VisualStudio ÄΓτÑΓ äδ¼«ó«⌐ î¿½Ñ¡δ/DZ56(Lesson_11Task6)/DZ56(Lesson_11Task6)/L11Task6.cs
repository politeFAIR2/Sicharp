﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ56_Lesson_11Task6_
{
    internal class L11Task6
    {
        static void Main(string[] args)
        {
            string s1 = "4 5";
            char c1 = '+';
            Console.WriteLine($"Строка: {s1}");
            Console.WriteLine($"Символ операции: {c1}");
            Console.WriteLine($"Результат: {Calculate(s1, c1)}");
            Console.WriteLine("+++++++++");
            string s2 = "4 5";
            char c2 = '*';
            Console.WriteLine($"Строка: {s2}");
            Console.WriteLine($"Символ операции: {c2}");
            Console.WriteLine($"Результат: {Calculate(s2, c2)}");
        }
        static string Calculate(string s, char c)
        {
            string[] parts = s.Split(' ');
            int a = int.Parse(parts[0]);
            int b = int.Parse(parts[1]);
            int result = 0;
            switch (c)
            {
                case '+':
                    result = a + b;
                    break;
                case '-':
                    result = a - b;
                    break;
                case '*':
                    result = a * b;
                    break;
                default:
                    throw new ArgumentException($"Неверный символ операции: {c}");
            }
            return $"{a}{c}{b}={result}";
        }
    }
}
