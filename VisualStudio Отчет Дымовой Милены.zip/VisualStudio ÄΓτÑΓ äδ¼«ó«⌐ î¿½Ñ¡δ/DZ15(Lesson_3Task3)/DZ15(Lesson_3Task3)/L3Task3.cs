﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ15_Lesson_3Task3_
{
    internal class L3Task3
    {
        static void Main(string[] args)
        {
            int positiveCount = 0;
            int negativeCount = 0;
            Console.WriteLine("Введите 10 целых чисел:");
            for (int i = 0; i < 10; i++)
            {
                int number = Int32.Parse(Console.ReadLine());

                if (number > 0)
                {
                    positiveCount++;
                }
                else if (number < 0)
                {
                    negativeCount++;
                }
            }
            Console.WriteLine($"Количество положительных чисел: {positiveCount}");
            Console.WriteLine($"Количество отрицательных чисел: {negativeCount}");
        }
    }
}
