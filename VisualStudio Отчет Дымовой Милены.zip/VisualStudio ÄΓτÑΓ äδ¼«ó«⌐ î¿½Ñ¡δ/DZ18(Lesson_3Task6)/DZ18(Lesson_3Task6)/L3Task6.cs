﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ18_Lesson_3Task6_
{
    internal class L3Task6
    {
        static void Main(string[] args)
        {
            double product = 1.0;
            Console.WriteLine("Введите 10 вещественных чисел:");
            for (int i = 0; i < 10; i++)
            {
                double number = double.Parse(Console.ReadLine());
                product *= number;
            }
            Console.WriteLine($"Произведение введенных чисел: {product:F6}");
        }
    }
}
