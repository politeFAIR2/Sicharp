﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dz_Lesson_1Task1_
{
    internal class L1Task1
    {
        static void Main(string[] args)
        {
            string firstName = "Ivan";
            string lastName = "Ivanov";
            DateTime dateOfBirth = new DateTime(1993, 1, 2);
            string address = "Rostov-on-Don";
            char gender = 'm';
            string country = "Russia";
            string courseName = "CS211";
            int courseGrade = 56;
            int lessonsPerWeek = 16;
            string instructor = "Mayer Svetlana";
            Console.WriteLine("Информация о студенте:");
            Console.WriteLine($"Имя: {firstName}, Фамилия: {lastName}, Дата рождения: {dateOfBirth.ToString("yyyy MM dd")},");
            Console.WriteLine($"Адрес: {address}, Пол: {gender}, Страна: {country}");
            Console.WriteLine("Course Information:");
            Console.WriteLine($"Название курса: {courseName}, Баллы: {courseGrade}, Количество занятий в неделю: {lessonsPerWeek}, Преподаватель: {instructor}");
        }
    }
}
