﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba10_Lesson_4Lab3_
{
    internal class L4Lab3
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите последовательность чисел и закончите ввод нулем");
            int numb;
            int min = int.MaxValue;
            try
            {
                do
                {
                    numb = Int32.Parse(Console.ReadLine());
                    if (numb < min && numb != 0)
                    {
                        min = numb;
                    }
                }
                while (numb != 0);
                Console.WriteLine($"Минимальное значение {min}");
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message + "Повторите ввод");
            }
        }
    }
}
