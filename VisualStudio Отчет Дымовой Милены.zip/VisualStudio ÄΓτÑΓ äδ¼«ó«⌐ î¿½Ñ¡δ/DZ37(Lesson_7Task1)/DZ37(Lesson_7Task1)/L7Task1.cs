﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ37_Lesson_7Task1_
{
    internal class L7Task1
    {
        static void Main(string[] args)
        {
            double[] arr = { 1.1, -2.3, 3.7, 4.1, 5.6, 6.1, 7.1 };
            Print(arr);
            double max = double.MinValue;
            double min = double.MaxValue;
            FindMaxMin(arr, ref max, ref min);
            Console.WriteLine($"максимальный элемент: {max}, минимальный элемент: {min}");
        }
        static void Print(double[] arr)
        {
            Console.WriteLine("Массив:");
            foreach (double num in arr)
            {
                Console.Write($"{num:F1} ");
            }
            Console.WriteLine();
        }
        static void FindMaxMin(double[] arr, ref double max, ref double min)
        {
            foreach (double num in arr)
            {
                if (num > max)
                {
                    max = num;
                }
                if (num < min)
                {
                    min = num;
                }
            }
        }
    }
}
