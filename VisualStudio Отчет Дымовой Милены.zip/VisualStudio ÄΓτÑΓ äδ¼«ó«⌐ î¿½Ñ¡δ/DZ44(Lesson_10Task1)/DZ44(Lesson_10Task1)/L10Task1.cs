﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ44_Lesson_10Task1_
{
    internal class L10Task1
    {
        static void Main(string[] args)
        {
            int[,] t = {
                {-8,-14,-19,-18},
                {25,28,26,20},
                {11,18,20,25}
            };
            Console.WriteLine($"1-е задание: {t[1, 3]} and {t[2, 0]}");
            Console.Write("2-е задание: ");
            for (int i = 0; i < 4; i++)
            {
                Console.Write($"{t[1, i]} ");
            }
            Console.WriteLine();
            Console.WriteLine("\n3-е задание:");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Console.Write($"{t[i, j]} ");
                }
                Console.WriteLine();
            }
            double sum = 0;
            for (int i = 0; i < 4; i++)
            {
                sum += t[2, i];
            }
            double avg = sum / 4;
            Console.WriteLine($"\n4-е задание: {avg:F2}");
            Console.WriteLine("\n5-е задание:");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    if (t[i, j] >= 24 && t[i, j] <= 26)
                    {
                        Console.WriteLine($"станция {i + 1} день {j}");
                    }
                }
            }
        }
    }
}
