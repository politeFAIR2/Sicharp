﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ32_Lesson_5Task7_
{
    internal class L5Task7
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите последовательность, завершите ввод 0");
            int counterPositive = 0;
            int counterNegative = 0;
            PosNegSeq(ref counterPositive, ref counterNegative);
            Console.WriteLine($"кол-во отрицательных: {counterNegative}, количество положительных: {counterPositive}");
        }
        static void PosNegSeq(ref int counterPositive, ref int counterNegative)
        {
            int number;
            while ((number = int.Parse(Console.ReadLine())) != 0)
            {
                if (number > 0)
                {
                    counterPositive++;
                }
                else if (number < 0)
                {
                    counterNegative++;
                }
            }
        }
    }
}
