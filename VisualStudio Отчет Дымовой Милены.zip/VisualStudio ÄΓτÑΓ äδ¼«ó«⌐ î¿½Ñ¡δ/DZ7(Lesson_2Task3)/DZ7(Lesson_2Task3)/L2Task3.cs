﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ7_Lesson_2Task3_
{
    internal class L2Task3
    {
        static void Main(string[] args)
        {
            Console.Write("Введите трехзначное число: ");
            int number = Int32.Parse(Console.ReadLine());
            int hundreds = number / 100;
            int tens = (number / 10) % 10;
            int units = number % 10;
            tens = 0;
            int newNumber = hundreds * 100 + tens * 10 + units;
            Console.WriteLine($"Цифры числа: {hundreds},{tens},{units}; результат: {newNumber}");
        }
    }
}
