﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace laba17_Lesson_7Lab2_
{
    internal class L7Lab2
    {
        static void Main(string[] args)
        {
            int[] arr = new int[10];
            FillRandomArray(arr, -10, 15);
            PrintArray(arr);
            DivisibleBy3(arr);
        }
        static void FillRandomArray(int[] arr, int minValue = -10, int maxValue = 15)
        {
            Random rand = new Random();
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = rand.Next(minValue, maxValue);
            }
        }
        static void PrintArray(int[] arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                Write($"{arr[i]} ");
            }
        }
        static void DivisibleBy3(int[] arr)
        {
            int counter = 0;
            WriteLine("элементы, кратные 3:");
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] % 3 == 0)
                {
                    Write($"{arr[i]}");
                    counter++;
                }
            }
            WriteLine();
            WriteLine($"кол-во элементов кратных 3: {counter}");
        }
    }
}
