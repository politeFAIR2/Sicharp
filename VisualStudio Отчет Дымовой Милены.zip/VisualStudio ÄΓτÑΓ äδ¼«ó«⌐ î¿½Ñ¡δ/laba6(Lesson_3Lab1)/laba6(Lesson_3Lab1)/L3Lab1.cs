﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba6_Lesson_3Lab1_
{
    internal class L3Lab1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число");
            int N = Int32.Parse(Console.ReadLine());
            for (int counter = 1; counter <= N; counter++)
            {
            Console.WriteLine($"Счетчик: {counter}");
            }
        }
    }
}
