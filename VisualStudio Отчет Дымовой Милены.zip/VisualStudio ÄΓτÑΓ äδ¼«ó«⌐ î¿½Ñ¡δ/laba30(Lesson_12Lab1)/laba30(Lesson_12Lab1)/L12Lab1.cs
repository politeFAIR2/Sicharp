﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Diagnostics;

namespace laba30_Lesson_12Lab1_
{
    internal class L12Lab1
    {
        static void Main(string[] args)
        {
            Debug.Assert(!IsPhonenumber("+7 (800) 231-45-84"));
            Debug.Assert(IsPhonenumber("+7 (863) 231-45-84"));
            Debug.Assert(!IsPhonenumber("+7 (8631) 21-45-84"));
            Console.WriteLine("Тесты пройдены");
            Console.WriteLine("Введите номер телефона:");
            string number = Console.ReadLine();
            Console.WriteLine(IsPhonenumber(number));
        }
        static bool IsPhonenumber(string number)
        {
            return Regex.IsMatch(number, @"^\+7\s\(863\)\s\d{3}-\d{2}-\d{2}$");
        }
    }
}
