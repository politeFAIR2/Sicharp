﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Math;
using static System.Console;


namespace DOPZ_Lesson_4ExTask1_
{
    internal class L4ExTask1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите x");
            for (int i = 0; i < 3; i++)
            {
                double x = double.Parse(ReadLine());
                double xMinusThree = x - 3;
                double y = 4 * Pow(xMinusThree, 6) - 7 * Pow(xMinusThree, 3) + 2;
                WriteLine($"x={x};y={y}");
                WriteLine("+++++");
            }
        }
    }
}
