﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Math;

namespace DZ28_Lesson_5Task3_
{
    internal class L5Task3
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите координаты двух точек (четыре целых числа: x1, y1, x2, y2):");
            int x1 = int.Parse(Console.ReadLine());
            int y1 = int.Parse(Console.ReadLine());
            int x2 = int.Parse(Console.ReadLine());
            int y2 = int.Parse(Console.ReadLine());
            Distance(x1, y1, x2, y2);
        }
        static void Distance(int x1, int y1, int x2, int y2)
        {
            double distance = Sqrt(Pow(x2 - x1, 2) + Pow(y2 - y1, 2));
            Console.WriteLine($"Расстояние: {distance:F0}");
        }
    }
}
