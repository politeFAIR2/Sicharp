﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ21_Lesson_4Task1_
{
    internal class L4Task1
    {
        static void Main(string[] args)
        {
            int counter1 = 3;
            Console.Write("While: ");
            while (counter1 <= 21)
            {
                Console.Write($"{counter1} ");
                counter1 += 2;
            }
            Console.WriteLine();
            int counter2 = 3;
            Console.Write("Do..While: ");
            do
            {
                Console.Write($"{counter2} ");
                counter2 += 2;
            } while (counter2 <= 21);
            Console.WriteLine();
        }
    }
}
