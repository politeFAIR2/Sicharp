﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace laba23_Lesson_10Lab1_
{
    internal class PL10Lab1
    {
        static void Main(string[] args)
        {
            int[,] arr2d = { { 1,  2 }, { 3,  4 }, { 5,  6 } };
            for (int i = 0; i < arr2d.GetLength(0); i++)
            {
                for (int j = 0; j < arr2d.GetLength(1); j++)
                {
                    Console.Write($"\n{arr2d[i, j]}");
                }
                Console.WriteLine();
            }
            Console.WriteLine($"1-й элемент = {arr2d[1, 0]}, 2-й элемент = {arr2d[2, 1]}");
        }
    }
}
