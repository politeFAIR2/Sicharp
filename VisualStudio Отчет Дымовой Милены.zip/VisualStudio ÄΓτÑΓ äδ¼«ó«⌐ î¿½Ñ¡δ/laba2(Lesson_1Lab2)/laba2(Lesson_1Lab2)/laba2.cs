﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba2_AddOne_
{
    internal class laba2
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            n++;
            Console.WriteLine(n);
            Console.ReadKey();
        }
    }
}

