﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ30_Lesson_5Task5_
{
    internal class L5Task5
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите двузначное число:");
            int number = int.Parse(Console.ReadLine());
            ChangeDigits(ref number);
            Console.WriteLine($"Результат: {number}");
        }
        static void ChangeDigits(ref int number)
        {
            int firstDigit = number / 10;
            int secondDigit = number % 10;
            number = secondDigit * 10 + firstDigit;
        }
    }
}
