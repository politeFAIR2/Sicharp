﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace DZ60_Lesson_14Task1_
{
    internal class L14Task1
    {
        static void Main(string[] args)
        {
            string path = @"L01.dat";

            try
            {
                using (var fs = new FileStream(path, FileMode.Open))
                using (var br = new BinaryReader(fs))
                {
                    WriteLine("Квадраты чисел:");

                    int evenCount = 0;

                    while (br.PeekChar() != -1)
                    {
                        int num = br.ReadInt32();
                        Write($"{num * num} ");

                        if (num % 2 == 0)
                            evenCount++;
                    }

                    WriteLine($"\nКоличество четных: {evenCount}");
                }
            }
            catch (IOException e)
            {
                WriteLine($"Ошибка чтения из файла: {e.Message}");
            }

            ReadKey();
        }
    }
}
