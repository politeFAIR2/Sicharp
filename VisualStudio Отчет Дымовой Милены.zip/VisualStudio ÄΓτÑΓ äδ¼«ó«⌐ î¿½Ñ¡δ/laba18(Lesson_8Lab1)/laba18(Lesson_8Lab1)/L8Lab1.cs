﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba18_Lesson_8Lab1_
{
    internal class L8Lab1
    {
        static void PrintSymbol <T> (T symbol)
        {
            for (int i = 0; i< 10; i++)
            {
                Console.Write($"{symbol}\n");
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine("\nВведите число");
            int symbolint = Int32.Parse(Console.ReadLine());
            PrintSymbol(symbolint);
            Console.WriteLine("\nВведите символ");
            string symbolStr = Console.ReadLine();
            PrintSymbol(symbolStr);
        }
    }
}
