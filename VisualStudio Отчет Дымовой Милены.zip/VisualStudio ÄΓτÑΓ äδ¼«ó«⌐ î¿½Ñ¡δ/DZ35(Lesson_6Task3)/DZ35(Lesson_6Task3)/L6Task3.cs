﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ35_Lesson_6Task3_
{
    internal class L6Task3
    {
        static void Main(string[] args)
        {
            int[] sequence = { -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5 };
            IEnumerable<int> positiveElements = sequence.Where(a => a > 0);
            Console.WriteLine("1) Положительные элементы:");
            PrintSequence(positiveElements);
            IEnumerable<int> multiplesOfFive = sequence.Where(a => a % 5 == 0);
            Console.WriteLine("2) Элементы, кратные 5:");
            PrintSequence(multiplesOfFive);
            IEnumerable<int> oddElements = sequence.Where(a => a % 2 != 0);
            Console.WriteLine("3) Нечетные элементы:");
            PrintSequence(oddElements);
        }
        static void PrintSequence(IEnumerable<int> sequence)
        {
            Console.WriteLine(string.Join(" ", sequence));
        }
    }
}