﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Math;

namespace laba14_Lesson_5Lab4_
{
    internal class L5Lab4
    {
        static void Main(string[] args)
        {
            int max = int.MinValue;
            int min = int.MaxValue;
            MinmaxSeq(ref max, ref min); //новый код
            WriteLine($"minimum is: {min}, maximum is: {max}");
        }

        private static void MinmaxSeq(ref int max, ref int min)
        {
            WriteLine("Введите последовательность и закончите ввод нулем");
            int a;
            do
            {
                a = Int32.Parse(ReadLine());
                if (a > max && a != 0) { max = a; }
                if (a < min && a != 0) { min = a; }
            }
            while (a != 0);
        }
    }
}
