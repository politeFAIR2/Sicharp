﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace DOPZ3_Lesson_4ExTask3_
{
    internal class L4ExTask2
    {
        static void Main(string[] args)
        {
            for (int row = 0; row < 8; row++)
            {
                for (int col = 0; col < 8; col++)
                {
                    if ((row + col) % 2 == 0)
                    {
                        Write("X");
                    }
                    else
                    {
                        Write("O");
                    }
                }
                WriteLine();
            }
        }
    }
}
