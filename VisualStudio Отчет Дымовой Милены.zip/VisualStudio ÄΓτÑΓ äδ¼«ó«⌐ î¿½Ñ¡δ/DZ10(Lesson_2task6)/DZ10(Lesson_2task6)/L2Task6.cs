﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ10_Lesson_2task6_
{
    internal class L2Task6
    {
        static void Main(string[] args)
        {
            Console.Write("Введите целое число x: ");
            int x = int.Parse(Console.ReadLine());
            int f;
            if (x < -2 || x > 2)
            {
                f = 2 * x;
            }
            else
            {
                f = -3 * x;
            }
            Console.WriteLine($"Значение функции f(x) = {f}");
        }
    }
}
