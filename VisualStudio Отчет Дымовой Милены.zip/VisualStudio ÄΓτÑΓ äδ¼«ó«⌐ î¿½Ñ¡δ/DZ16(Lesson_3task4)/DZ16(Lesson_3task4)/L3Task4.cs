﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ16_Lesson_3task4_
{
    internal class L3Task4
    {
        static void Main(string[] args)
        {
            int sum = 0;
            Console.WriteLine("Введите 10 целых чисел:");
            for (int i = 0; i < 10; i++)
            {
                int number = int.Parse(Console.ReadLine());
                sum += number;
            }
            Console.WriteLine($"Сумма введенных чисел: {sum}");
        }
    }
}
