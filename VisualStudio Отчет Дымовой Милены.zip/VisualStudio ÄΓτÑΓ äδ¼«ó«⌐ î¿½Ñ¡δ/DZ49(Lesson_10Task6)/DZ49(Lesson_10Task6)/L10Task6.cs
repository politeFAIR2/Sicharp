﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ49_Lesson_10Task6_
{
    internal class L10Task6
    {
        static void Main(string[] args)
        {
            int[,] matrix = {
                {-10, -3, -7, -4},
                {-6, 4, 1, 0},
                {-5, -1, -8, -5}
            };
            Console.WriteLine("Матрица:");
            PrintMatrix(matrix);
            Console.Write("Введите номер столбца (первый столбец - 0-й): ");
            int column = int.Parse(Console.ReadLine());
            int product;
            FindProductOfColumn(matrix, column, out product);
            Console.WriteLine($"Произведение элементов {column}-го столбца = {product}");
        }
        static void PrintMatrix(int[,] matrix)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write($"{matrix[i, j],4} ");
                }
                Console.WriteLine();
            }
        }
        static void FindProductOfColumn(int[,] matrix, int M, out int product)
        {
            product = 1;
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                product *= matrix[i, M];
            }
        }
    }
}
