﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ51_Lesson_11Task1_
{
    internal class L11Task1
    {
        static void Main(string[] args)
        {
            Console.Write("Введите символ: ");
            char c = Console.ReadLine()[0];
            string s1 = $"astra{c}str{c}a";
            string s2 = $"nana{c}na{c}";
            Console.WriteLine($"Результат для строки {s1} и символа {c}: {BetweenChars(s1, c)}");
            Console.WriteLine($"Результат для строки {s2} и символа {c}: {BetweenChars(s2, c)}");
        }
        static string BetweenChars(string s, char c)
        {
            int start = s.IndexOf(c);
            int end = s.LastIndexOf(c);

            if (start == -1 || end == -1 || start == end)
                return "";
            return s.Substring(start + 1, end - start - 1);
        }
    }
}
