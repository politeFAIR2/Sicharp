﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ17_Lesson_3task5_
{
    internal class L3Task5
    {
        static void Main(string[] args)
        {
            int sum = 0;
            Console.Write("Последовательность: ");
            for (int i = 1; i <= 19; i += 2)
            {
                Console.Write($"{i}");
                if (i < 19)
                {
                    Console.Write(" + ");
                }
                sum += i;
            }
            Console.WriteLine($" => сумма = {sum}");
        }
    }
}
