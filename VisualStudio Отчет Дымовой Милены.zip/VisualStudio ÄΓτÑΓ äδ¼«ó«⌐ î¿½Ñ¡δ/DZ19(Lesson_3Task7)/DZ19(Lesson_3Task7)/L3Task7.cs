﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ19_Lesson_3Task7_
{
    internal class L3Task7
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Значения функции z(x,y) = xy в интервале x [2;8], y [2;5]:");
            for (double x = 2; x <= 8; x++)
            {
                for (double y = 2; y <= 5; y++)
                {
                    double z = Math.Pow(x, y);
                    Console.WriteLine($"z(x,y) = {x}^{y} = {z}");
                }
            }
        }
    }
}
