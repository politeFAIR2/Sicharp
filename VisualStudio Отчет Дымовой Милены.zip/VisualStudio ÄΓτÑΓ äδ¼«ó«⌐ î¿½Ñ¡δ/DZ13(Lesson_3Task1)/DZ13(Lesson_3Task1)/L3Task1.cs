﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ13_Lesson_3Task1_
{
    internal class L3Task1
    {
        static void Main(string[] args)
        {
            Console.Write("Последовательность: ");
            for (int counter = -3; counter <= 24; counter += 3)
            {
                Console.Write($"{counter} ");
            }
        }
    }
}
