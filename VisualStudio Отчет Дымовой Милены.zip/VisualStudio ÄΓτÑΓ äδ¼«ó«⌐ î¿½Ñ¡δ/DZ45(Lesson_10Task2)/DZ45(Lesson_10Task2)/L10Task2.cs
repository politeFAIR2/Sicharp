﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ45_Lesson_10Task2_
{
    internal class L10Task2
    {
        static void Main(string[] args)
        {
            int[,] arr = new int[2, 3];
            Console.WriteLine("Введите 6 значений для матрицы 2 х 3");
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    arr[i, j] = int.Parse(Console.ReadLine());
                }
            }
            Console.WriteLine("\nМатрица:");
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write($"{arr[i, j]} ");
                }
                Console.WriteLine();
            }
            int sum = 0;
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    sum += arr[i, j];
                }
            }
            Console.WriteLine($"\nСумма = {sum}");
        }
    }
}
