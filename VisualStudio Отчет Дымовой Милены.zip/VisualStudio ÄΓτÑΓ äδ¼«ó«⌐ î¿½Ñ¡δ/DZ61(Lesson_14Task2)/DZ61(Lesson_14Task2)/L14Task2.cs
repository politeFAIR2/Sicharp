﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace DZ61_Lesson_14Task2_
{
    internal class L14Task2
    {
        static void Main(string[] args)
        {
            string path = @"Task02.dat";
            try
            {
                using (var fs = new FileStream(path, FileMode.Open))
                using (var br = new BinaryReader(fs, Encoding.ASCII))
                {
                    PrintData(path);
                    WriteLine($"Количество чисел, меньших, чем их левый сосед: {CountLessThanLeft(path)}");
                }
            }
            catch (IOException e)
            {
                WriteLine($"Ошибка при открытии файла: {e.Message}");
            }
            ReadKey();
        }
        static void PrintData(string path)
        {
            try
            {
                using (var fs = new FileStream(path, FileMode.Open))
                using (var br = new BinaryReader(fs, Encoding.ASCII))
                {
                    WriteLine("Числа в файле:");

                    while (br.PeekChar() != -1)
                    {
                        Write($"{br.ReadInt32()} ");
                    }

                    WriteLine();
                }
            }
            catch (IOException e)
            {
                WriteLine($"Ошибка при работе с файлом: {e.Message}");
            }
        }
        static int CountLessThanLeft(string path)
        {
            int count = 0;
            int prevNum = int.MaxValue;
            try
            {
                using (var fs = new FileStream(path, FileMode.Open))
                using (var br = new BinaryReader(fs, Encoding.ASCII))
                {
                    while (br.PeekChar() != -1)
                    {
                        int num = br.ReadInt32();
                        if (num < prevNum)
                            count++;
                        prevNum = num;
                    }
                }
            }
            catch (IOException e)
            {
                WriteLine($"Ошибка при работе с файлом: {e.Message}");
            }

            return count;
        }
    }
}
