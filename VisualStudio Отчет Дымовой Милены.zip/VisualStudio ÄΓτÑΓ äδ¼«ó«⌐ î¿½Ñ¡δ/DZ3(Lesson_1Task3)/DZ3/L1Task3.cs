﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ3
{
    internal class L1Task3
    {
        static void Main(string[] args)
        {
            Console.Write("Введите сторону треугольника, пожалуйста: ");
            double side = double.Parse(Console.ReadLine());
            double perimeter = 3 * side;
            double area = (side * side * Math.Sqrt(3)) / 4;
            Console.WriteLine($"Периметр треугольника: {perimeter}");
            Console.WriteLine($"Площадь: {area}");
            Console.ReadKey();
        }
    }
}
