﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ43_Lesson_9Task2_
{
    internal class L9Task2
    {
        static void Main(string[] args)
        {
            Minimum minimum = new Minimum();
            int[] result1 = minimum.FindMin(5, 3, 6);
            Console.WriteLine("Результат с тремя параметрами (5, 3, 6):");
            foreach (int i in result1)
            {
                Console.WriteLine(i);
            }
            int[] arr = { 5, 3, 3, 6, 5 };
            int[] result2 = minimum.FindMin(arr);
            Console.WriteLine("\nРезультат с целочисленным массивом (5, 3, 3, 6, 5):");
            foreach (int i in result2)
            {
                Console.WriteLine(i);
            }
        }
    }
}
