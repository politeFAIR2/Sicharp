﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ43_Lesson_9Task2_
{
    internal class Minimum
    {
        public int[] FindMin(params int[] numbers)
        {
            int[] result = new int[numbers.Length];
            int min = int.MaxValue;
            foreach (int num in numbers)
            {
                if (num < min)
                {
                    min = num;
                }
            }
            for (int i = 0; i < numbers.Length; i++)
            {
                if (numbers[i] == min)
                {
                    result[i] = 0;
                }
                else
                {
                    result[i] = numbers[i];
                }
            }
            return result;
        }
    }
}
