﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba11_Lesson_5Lab1_
{
    internal class L5Lab1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите два числа");
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            //Sum(a, b);
            int result = Sum(a, b);
            Console.WriteLine($"Вызов sum() с двумя аргументами: {result}");

            int result3 = Sum(10, 50, 80);
            Console.WriteLine($"Вызов sum() с тремя аргументами: {result}");

            double dbResult = Sum(20.5, 30.6);
            Console.WriteLine($"Вызов sum() с вещественными аргументами: {dbResult}");
        }

        static double Sum(double first, double second)
        {
            double result = first + second;
            return result;
        }

        static int Sum(int first, int second, int third)
        {
            int sum = first + second + third;
            return sum;
        }

        static int Sum(int first, int second)
        {
            int sum = first + second;
            return sum;
        }


        ////private static void Sum(int first, int second)
        //{
        //    int sum = first + second;
        //    Console.WriteLine($"Сумма {first} + {second} = {sum}");

        //}
    }
}
