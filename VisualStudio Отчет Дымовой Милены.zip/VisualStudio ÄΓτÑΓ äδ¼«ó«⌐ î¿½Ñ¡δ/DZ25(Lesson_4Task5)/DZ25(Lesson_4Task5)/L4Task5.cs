﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ25_Lesson_4Task5_
{
    internal class L4Task5
    {
        static void Main(string[] args)
        {
            int maxNumber = int.MinValue;
            int maxNumberIndex = 0;
            int counter = 1;
            int number;

            Console.WriteLine("Введите последовательность чисел и закончите ввод нулем");
            do
            {
                number = int.Parse(Console.ReadLine());

                if (number != 0 && number > maxNumber)
                {
                    maxNumber = number;
                    maxNumberIndex = counter;
                }
                counter++;
            } while (number != 0);
            Console.WriteLine($"Максимальное число {maxNumber}, его порядковый номер {maxNumberIndex}");
        }
    }
}
