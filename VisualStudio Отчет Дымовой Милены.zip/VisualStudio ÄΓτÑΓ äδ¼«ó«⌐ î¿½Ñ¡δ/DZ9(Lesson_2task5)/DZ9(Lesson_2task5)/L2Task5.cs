﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ9_Lesson_2task5_
{
    internal class L2Task5
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите три целых числа:");
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());
            bool exists = a + b > c && a + c > b && b + c > a;
            if (exists)
            {
                double p = (a + b + c) / 2.0;
                double area = Math.Sqrt(p * (p - a) * (p - b) * (p - c));
                Console.WriteLine($"Результат: существует, его площадь {area:F6}");
            }
            else
            {
                Console.WriteLine("Результат: не существует");
            }
        }
    }
}
