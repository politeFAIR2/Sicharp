﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DZ57_Lesson_12Task1_
{
    internal class L12Task1
    {
        static void Main(string[] args)
        {
            Debug.Assert(!IsDateValid("12/03/1975"));
            Debug.Assert(!IsDateValid("2-3-1975"));
            Debug.Assert(IsDateValid("12-03-1975"));
            Debug.Assert(IsDateValid("01-02-2023"));
            Console.WriteLine("Тесты пройдены корректно");
            Console.WriteLine("Пожалуйста, введите дату:");
            string dateInput = Console.ReadLine();
            if (IsDateValid(dateInput))
                Console.WriteLine("Формат даты верный");
            else
                Console.WriteLine("Формат даты неверный");
            Console.WriteLine("+++++++++");
        }
        static bool IsDateValid(string dateString)
        {
            return Regex.IsMatch(dateString, @"^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[0-2])-\d{4}$");
        }
    }
}
