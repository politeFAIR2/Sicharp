﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ20_Lesson_3Task8_
{
    internal class L3Task8
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Значения функции z(x,y) = x - y в интервале x [30;33], y [1;5]:");
            for (int x = 30; x <= 33; x++)
            {
                for (int y = 1; y <= 5; y++)
                {
                    int z = x - y;
                    Console.WriteLine($"z(x,y) = {x} - {y} = {z}");
                }
            }
        }
    }
}
