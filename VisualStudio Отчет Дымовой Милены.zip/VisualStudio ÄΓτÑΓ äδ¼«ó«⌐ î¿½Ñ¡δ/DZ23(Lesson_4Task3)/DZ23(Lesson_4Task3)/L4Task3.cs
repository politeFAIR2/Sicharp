﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ23_Lesson_4Task3_
{
    internal class L4Task3
    {
        static void Main(string[] args)
        {
            int product = 1;
            int num = 10;
            Console.Write("10 * 12 * 14 * 16 * 18 * 20  =  ");
            while (num <= 20)
            {
                product *= num;
                num += 2;
            }
            Console.WriteLine(product);
        }
    }
}
