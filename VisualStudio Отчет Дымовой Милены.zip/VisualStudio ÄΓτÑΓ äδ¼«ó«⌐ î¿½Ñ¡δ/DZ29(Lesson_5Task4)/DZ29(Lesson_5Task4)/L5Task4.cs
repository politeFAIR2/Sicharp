﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Math;


namespace DZ29_Lesson_5Task4_
{
    internal class L5Task4
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите координаты двух точек (четыре вещественных числа: x1, y1, x2, y2):");
            double x1 = double.Parse(Console.ReadLine());
            double y1 = double.Parse(Console.ReadLine());
            double x2 = double.Parse(Console.ReadLine());
            double y2 = double.Parse(Console.ReadLine());
            double distance = Distance(x1, y1, x2, y2);
            Console.WriteLine($"Расстояние: {distance:F4}");
        }
        static double Distance(double x1, double y1, double x2, double y2)
        {
            return Sqrt(Pow(x2 - x1, 2) + Pow(y2 - y1, 2));
        }
    }
}
