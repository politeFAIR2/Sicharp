﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ24_Lesson_4Task4_
{
    internal class L4Task4
    {
        static void Main(string[] args)
        {
            double sum = 0;
            int counter = 0;
            Console.WriteLine("Введите 5 вещественных чисел:");
            while (counter < 5)
            {
                double numb = double.Parse(Console.ReadLine());
                sum += numb;
                counter++;
            }
            Console.WriteLine($"Сумма введенных чисел = {sum}");
        }
    }
}
