﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ11_Lesson_2task7_
{
    internal class L2Task7
    {
        static void Main(string[] args)
        {
            Console.Write("Введите вещественное число x: ");
            double x = double.Parse(Console.ReadLine());
            int f;
            if (x > 0)
            {
                f = (int)(2 * Math.Sin(x));
            }
            else
            {
                f = 6 - (int)x;
            }
            Console.WriteLine($"Значение функции f(x) = {f}");
        }
    }
}
