﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba19_Lesson_8Lab2_
{
    internal class L8Lab2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\nВведите число");
            int symbolInt = Int32.Parse(Console.ReadLine());
            MyFuncs.PrintSymbol(symbolInt);
        }
    }
    class MyFuncs
    {
        public static void PrintSymbol<T>(T symbol)
        {
            for (var i = 0;  i < 10; i++)
            {
                Console.WriteLine($"{symbol}");
            }
        }
    }
}
