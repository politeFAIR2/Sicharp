﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba20_Lesson_8Lab2_
{
    internal class MyFunctsLab3
    {
        public static void PrintSymbol <T>(T symbol)
        {
            for (var i = 0; i < 10; i++)
            {
                Console.Write($"{symbol}\n");
            }
        }
    }
}
