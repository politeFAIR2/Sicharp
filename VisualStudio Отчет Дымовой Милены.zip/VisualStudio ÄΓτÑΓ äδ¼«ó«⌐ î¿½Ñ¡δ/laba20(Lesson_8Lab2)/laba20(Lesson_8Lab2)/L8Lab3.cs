﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba20_Lesson_8Lab2_
{
    internal class L8Lab3
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число");
            int symbolInt = Int32.Parse(Console.ReadLine());
            MyFunctsLab3.PrintSymbol(symbolInt);
        }
     }
}

