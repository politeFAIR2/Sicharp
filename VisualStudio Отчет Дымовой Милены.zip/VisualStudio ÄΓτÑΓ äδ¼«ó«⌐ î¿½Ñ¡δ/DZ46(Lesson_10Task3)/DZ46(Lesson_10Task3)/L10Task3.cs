﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ46_Lesson_10Task3_
{
    internal class L10Task3
    {
        static void Main(string[] args)
        {
            int[,] arr = new int[4, 3];
            Console.WriteLine("Пожалуйста, введите значения матрицы 4 х 3");
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    arr[i, j] = int.Parse(Console.ReadLine());
                }
            }
            Console.WriteLine("\nМатрица:");
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write($"{arr[i, j]} ");
                }
                Console.WriteLine();
            }
            int positiveCount = 0;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (arr[i, j] > 0)
                    {
                        positiveCount++;
                    }
                }
            }
            Console.WriteLine($"\nКоличество положительных = {positiveCount}");
        }
    }
}
