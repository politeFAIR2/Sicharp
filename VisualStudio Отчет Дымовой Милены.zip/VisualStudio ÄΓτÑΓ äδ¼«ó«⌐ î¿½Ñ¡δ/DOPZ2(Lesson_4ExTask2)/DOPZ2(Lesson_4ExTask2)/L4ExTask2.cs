﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Math;

namespace DOPZ2_Lesson_4ExTask2_
{
    internal class L4ExTask2
    {
        static void Main(string[] args)
        {
            Write("Введите x (1-8): ");
            int x = int.Parse(ReadLine());
            Write("Введите y (1-8): ");
            int y = int.Parse(ReadLine());
            bool isWhite = ((x + y) % 2) == 0;
            WriteLine($"Этот квадрат белый: {isWhite}");
        }
    }
}
