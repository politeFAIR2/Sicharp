﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ36_Lesson_6Task4_
{
    internal class L6Task4
    {
        static void Main(string[] args)
        {
            int[] sequence = Enumerable.Range(1, 9).ToArray();
            Console.WriteLine(string.Join(" ", sequence));
            int[] shiftedSequence = sequence.Select(a => a + 2).ToArray();
            Console.WriteLine(string.Join(" ", shiftedSequence));
        }
    }
}
