﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ8_Lesson_2task4_
{
    internal class L2Task4
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите три целых числа:");
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());
            bool result = (a != b) || (a != c) || (b != c);
            Console.WriteLine($"Результат: {result}");
        }
    }
}
