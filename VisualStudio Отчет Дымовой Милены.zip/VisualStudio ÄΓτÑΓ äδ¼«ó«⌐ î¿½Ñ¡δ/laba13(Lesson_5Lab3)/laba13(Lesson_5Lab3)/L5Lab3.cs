﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba13_Lesson_5Lab3_
{
    internal class L5Lab3
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите два числа");
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            Minmax(ref a, ref b);
            Console.WriteLine($"Результат после метода Minmax: {a},{b}");
            Console.WriteLine("Введите три числа");
            a = int.Parse(Console.ReadLine());
            b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());
            Minmax(ref a, ref b, ref c);
            Console.WriteLine($"Результат после  перезагрузки метода Minmax: {a},{b},{c}");
        }
        static void Minmax(ref int a, ref int b)
        {
            int max = Math.Max(a, b);
            int min = Math.Min(a, b);
            a = max;
            b = min;
        }
        static void Minmax(ref int a, ref int b, ref int c)
        {
            Minmax(ref a, ref b);
            Minmax(ref b, ref c);
            Minmax(ref a, ref b);
        }
    }
}
