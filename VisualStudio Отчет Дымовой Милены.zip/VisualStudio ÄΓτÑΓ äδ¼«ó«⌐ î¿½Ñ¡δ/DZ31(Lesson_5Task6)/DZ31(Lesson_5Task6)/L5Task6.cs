﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ31_Lesson_5Task6_
{
    internal class L5Task6
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите два двузначных целых числа:");
            int number1 = int.Parse(Console.ReadLine());
            int number2 = int.Parse(Console.ReadLine());

            int result = BitwiseSum(number1, number2);
            Console.WriteLine($"Побитовая сумма чисел {number1} и {number2} = {result}");
        }
        static int BitwiseSum(int number1, int number2)
        {
            int firstDigit1 = number1 / 10;
            int secondDigit1 = number1 % 10;
            int firstDigit2 = number2 / 10;
            int secondDigit2 = number2 % 10;
            int sum = (firstDigit1 + firstDigit2) % 10 * 10 + (secondDigit1 + secondDigit2) % 10;
            return sum;
        }
    }
}
