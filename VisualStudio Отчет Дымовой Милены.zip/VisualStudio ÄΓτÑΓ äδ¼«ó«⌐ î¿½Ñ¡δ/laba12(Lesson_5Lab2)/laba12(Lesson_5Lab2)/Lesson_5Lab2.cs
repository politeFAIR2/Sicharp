﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba12_Lesson_5Lab2_
{
    internal class Lesson_5Lab2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите два числа - число и степень числа: ");
            int a = Int32.Parse(Console.ReadLine());
            int b = Int32.Parse(Console.ReadLine());
            Console.WriteLine(GetPow(a, b));
        }
        static int GetPow (int baseNum, int powNum)
        {
            int result = 1;
            for (int i = 0; i < powNum; i++)
            {
                result = result * baseNum;
            }
            return result;
        }
    }
}
