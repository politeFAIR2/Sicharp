﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ42_Lesson_9Task1_
{
    internal class L9Task1
    {
        static void Main(string[] args)
        {
            int[] intArray = { 1, 6, 2, 7, 5 };
            MyFuncs.PrintArray(intArray);
            MyFuncs.PrintEvenIndexes(intArray);

            double[] doubleArray = { 1.2, 6.4, 2.1, 7.5, 8.1 };
            MyFuncs.PrintArray(doubleArray);
            MyFuncs.PrintEvenIndexes(doubleArray);
        }
    }
    public static class MyFuncs
    {
        public static void PrintArray<T>(T[] arr)
        {
            Console.WriteLine($"Массив типа {typeof(T)}:");
            foreach (T item in arr)
            {
                Console.Write($"{item} ");
            }
            Console.WriteLine();
        }
        public static void PrintEvenIndexes<T>(T[] arr)
        {
            Console.WriteLine($"Элементы с четными индексами:");
            for (int i = 0; i < arr.Length; i += 2)
            {
                Console.Write($"{arr[i]} ");
            }
            Console.WriteLine();
        }
    }
}
