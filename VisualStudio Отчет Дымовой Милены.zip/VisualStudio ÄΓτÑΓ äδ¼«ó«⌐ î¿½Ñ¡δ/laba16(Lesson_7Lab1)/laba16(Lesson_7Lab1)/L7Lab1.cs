﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace laba16_Lesson_7Lab1_
{
    internal class L7Lab1
    {
        static void Main(string[] args)
        {
            int[] a = new int[] { -1, -2, 3, 4, 5, 6, 7 };
            Print(a);
            int countPos = 0;
            int countOdd = 0;
            CountOddPositive(a, ref countPos, ref countOdd);
            WriteLine($"кол-во нечетных элементов: {countOdd}, количество положительных элементов {countOdd}");
        }
        static void Print(int[] arr)
        {
            WriteLine("Массив:");
            foreach (var x in arr)
                Write(x + " ");
            WriteLine();
        }
        static void CountOddPositive (int[] arr, ref int countOdd,ref int countPos)
        {
            foreach (var x in arr)
            {
                if (x % 2 !=0)
                    countOdd++;
                if (x > 0)
                    countPos++;
            }
        }
    }
}
