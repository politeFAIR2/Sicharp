﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba3
{
    internal class L1Lab3
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите три числа");
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());
            //Console.WriteLine(a < b && b < c);
            Console.WriteLine($"{a} < {b} < {c}= {a < b && b < c}");
            Console.ReadKey();
        }
    }
}
