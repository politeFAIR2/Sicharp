﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba8_Lesson_4Lab1_
{
    internal class L4Lab1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число");
            int N = Int32.Parse(Console.ReadLine());
            int counter = 1;
            while (counter <= N)
            {
                Console.WriteLine($"Текущее значение счетчика:{counter} ");
                counter++;
            }
        }
    }
}
