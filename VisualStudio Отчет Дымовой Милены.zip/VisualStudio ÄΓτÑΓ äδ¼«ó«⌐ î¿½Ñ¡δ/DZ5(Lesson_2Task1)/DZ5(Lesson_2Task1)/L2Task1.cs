﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ5_Lesson_2Task1_
{
    internal class L2Task1
    {
        static void Main(string[] args)
        {
            Console.Write("Введите число: ");
            int number = int.Parse(Console.ReadLine());
            if (number > 0)
            {
                Console.WriteLine("Результат: введенное число положительное");
            }
            else if (number < 0)
            {
                Console.WriteLine("Результат: введенное число отрицательное");
            }
            else
            {
                Console.WriteLine("Результат: введенное число равно нулю");
            }
        }
    }
}
