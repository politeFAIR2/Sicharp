﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ2
{
    internal class L1Task2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите два числа:");
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            double average = (a + b) / 2.0;
            Console.WriteLine($"Среднее арифметическое: {average}");
            Console.ReadKey();
        }
    }
}
