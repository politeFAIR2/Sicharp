﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.IO;

namespace laba33_Lesson_14Lab1_
{
    internal class L14Lab1
    {
        static void Main(string[] args)
        {
            string path = @"L01.dat";
            try
            {
                using (var fs = new FileStream(path, FileMode.Open))
                using (var br = new BinaryReader(fs))
                {
                    WriteLine("Данные из файла:");
                    while (br.PeekChar() != -1)
                    {
                        Write($"{br.ReadInt32()} ");
                    }
                    WriteLine("\n");
                }
            }
            catch (IOException e)
            {
                WriteLine($"Ошибка чтения из файла: {e.Message}");
            }
            ReadKey();
        }
    }
}
