﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba26_Lesson_10Lab4_
{
    internal class L10Lab4
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите размерность матрицы:");
            int M = int.Parse(Console.ReadLine());

            int[,] matrix = FillMatrix(M, M);

            Console.WriteLine($"Матрица {M}х{M}:");
            PrintMatrix(matrix);

            int result = AntidiagonalSum(matrix);
            Console.WriteLine($"Сумма элементов побочной диагонали = {result}");
        }

        static int[,] FillMatrix(int rows, int cols)
        {
            int[,] matrix = new int[rows, cols];
            Random rand = new Random();

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    matrix[i, j] = rand.Next(1, 16);
                }
            }

            return matrix;
        }

        static void PrintMatrix(int[,] matrix)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write($"{matrix[i, j],4} ");
                }
                Console.WriteLine();
            }
        }

        static int AntidiagonalSum(int[,] matrix)
        {
            int sum = 0;
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    if (i + j == matrix.GetLength(0) - 1)
                    {
                        sum += matrix[i, j];
                    }
                }
            }
            return sum;
        }
    }
}

