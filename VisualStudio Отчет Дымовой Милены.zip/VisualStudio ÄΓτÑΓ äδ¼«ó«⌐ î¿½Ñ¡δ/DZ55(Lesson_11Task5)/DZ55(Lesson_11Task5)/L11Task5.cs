﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ55_Lesson_11Task5_
{
    internal class L11Task5
    {
        static void Main(string[] args)
        {
            string string1 = "1234";
            string string2 = "123456";
            Console.WriteLine($"string1={string1}.  string2={string2}.");
            string result1 = AddSpaces(string1, string2.Length - string1.Length);
            string result2 = string2;
            Console.WriteLine($"result: string1={result1}.  string2={result2}.");
        }
        static string AddSpaces(string s, int spacesToAdd)
        {
            StringBuilder sb = new StringBuilder(s);
            sb.Append(new string(' ', spacesToAdd));
            return sb.ToString();
        }
    }
}
