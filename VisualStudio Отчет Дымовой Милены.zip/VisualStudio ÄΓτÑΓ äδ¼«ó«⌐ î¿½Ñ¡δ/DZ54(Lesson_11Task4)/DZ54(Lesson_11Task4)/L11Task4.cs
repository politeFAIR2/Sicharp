﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ54_Lesson_11Task4_
{
    internal class L11Task4
    {
        static void Main(string[] args)
        {
            string s1 = "ast*qqra*";
            string s2 = "POW*EROFBULL";
            Console.WriteLine($"Результат для строки {s1} и символа *: {RemoveBetweenChars(s1)}");
            Console.WriteLine($"Результат для строки {s2} и символа *: {RemoveBetweenChars(s2)}");
        }
        static string RemoveBetweenChars(string s, char c = '*')
        {
            int firstIndex = s.IndexOf(c);
            if (firstIndex == -1)
                return s;
            int secondIndex = s.IndexOf(c, firstIndex + 1);
            if (secondIndex == -1)
                return s.Substring(0, firstIndex);
            return s.Remove(firstIndex, secondIndex - firstIndex + 1);
        }
    }
}
