﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ40_Lesson_8Task1_
{
    internal class L8Task1
    {
        static void Main(string[] args)
        {
            Console.Write("Введите два числа: ");
            int num1 = int.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine());
            int sum = MyFuncs.Add(num1, num2);
            Console.WriteLine($"Сумма: {sum}");
        }
    }
    public static class MyFuncs
    {
        public static int Add(int i, int j)
        {
            return i + j;
        }
    }
}
