﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DZ58_Lesson_12Task2_
{
    internal class L12Task2
    {
        static void Main(string[] args)
        {
            Debug.Assert(CountSmileys("Привет папа! Я скучаю.") == 2);
            Debug.Assert(CountSmileys("Привет, как дела? :) :)") == 2);
            Debug.Assert(CountSmileys("Привет, как дела? :-D") == 1);
            Debug.Assert(CountSmileys("Привет, как дела? :-----) ") == 0);
            Console.WriteLine("Тесты пройдены");
            string text = "Привет папа! Я скучаю.";
            Console.WriteLine($"Для строки '{text}' имеем {CountSmileys(text)} смайлика");
        }
        static int CountSmileys(string text)
        {
            return Regex.Matches(text, @"^[:;][-]?[\)|\]]$|^[:;][-]?[\(|\[]$").Count;
        }
    }
}
