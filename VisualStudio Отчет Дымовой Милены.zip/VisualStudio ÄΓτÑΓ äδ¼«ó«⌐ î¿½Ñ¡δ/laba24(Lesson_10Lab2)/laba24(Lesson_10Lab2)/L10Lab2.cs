﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace laba24_Lesson_10Lab2_
{
    internal class L10Lab2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите кол-во строк");
            int rows = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите кол-во столбцов");
            int columns = int.Parse(Console.ReadLine());
            int[,] matrix = new int[rows, columns];
            int minValue = -10;
            int maxValue = 10;
            FillMatrix(matrix, minValue, maxValue);
        }

        private static void FillMatrix(int[,] matrix, int minValue = -10, int maxValue = 10)
        {
            Random rand = new Random();
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    matrix[i, j] = rand.Next(minValue, maxValue);
                    Write(matrix[i, j].ToString().PadLeft(4));
                }
                WriteLine();
            }
        }
    }
}
