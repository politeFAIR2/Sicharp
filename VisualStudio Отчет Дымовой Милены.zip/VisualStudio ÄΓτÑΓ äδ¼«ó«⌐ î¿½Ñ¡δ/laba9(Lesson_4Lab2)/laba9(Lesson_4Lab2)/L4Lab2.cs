﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba9_Lesson_4Lab2_
{
    internal class L4Lab2
    {
        static void Main(string[] args)
        {
            int counter = 1;
            do
            {
                Console.WriteLine($"Текущее значение счетчика: {counter}");
                counter++;
            }
            while (counter <= 5);
        }
    }
}
