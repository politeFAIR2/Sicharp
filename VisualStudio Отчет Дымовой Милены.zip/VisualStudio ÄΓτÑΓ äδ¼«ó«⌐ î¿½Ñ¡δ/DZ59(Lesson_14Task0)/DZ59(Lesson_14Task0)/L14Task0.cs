﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ59_Lesson_14Task0_
{
    internal class L14Task0
    {
        static void Main(string[] args)
        {
            string filePath = @"D:\myFile.txt";
            Console.WriteLine("Введите строку:");
            string inputString = Console.ReadLine();
            WriteToFile(filePath, inputString);
            string readString = ReadFromFile(filePath);
            Console.WriteLine($"Строка из файла:\n{readString}");
        }
        static void WriteToFile(string filePath, string content)
        {
            byte[] bytes = Encoding.Default.GetBytes(content);

            using (FileStream fs = new FileStream(filePath, FileMode.Create))
            {
                fs.Write(bytes, 0, bytes.Length);
            }
        }
        static string ReadFromFile(string filePath)
        {
            byte[] bytes;
            using (FileStream fs = new FileStream(filePath, FileMode.Open))
            {
                bytes = new byte[fs.Length];
                fs.Read(bytes, 0, (int)fs.Length);
            }
            return Encoding.Default.GetString(bytes);
        }
    }
}
