﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ33_Lesson_6Task1_
{
    internal class L6Task1
    {
        enum DayOfWeek { MON, TUE, WED, THU, FRI, SAT, SUN };
        static void PrintDayOfWeek(DayOfWeek dow)
        {
            switch (dow)
            {
                case DayOfWeek.MON:
                    Console.WriteLine("Понедельник");
                    break;
                case DayOfWeek.TUE:
                    Console.WriteLine("Вторник");
                    break;
                case DayOfWeek.WED:
                    Console.WriteLine("Среда");
                    break;
                case DayOfWeek.THU:
                    Console.WriteLine("Четверг");
                    break;
                case DayOfWeek.FRI:
                    Console.WriteLine("Пятница");
                    break;
                case DayOfWeek.SAT:
                    Console.WriteLine("Суббота");
                    break;
                case DayOfWeek.SUN:
                    Console.WriteLine("Воскресенье");
                    break;
            }
        }
        static DayOfWeek ReadDayOfWeek()
        {
            int day;
            day = int.Parse(Console.ReadLine());
            if (day < 1 || day > 7)
                throw new ArgumentOutOfRangeException("day", "day must be > 0 and <8; day=" + day.ToString());
            return (DayOfWeek)(day - 1);
        }
        static void Main()
        {
            DayOfWeek dow = ReadDayOfWeek();
            PrintDayOfWeek(dow);
        }
    }
}
