﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Math;
namespace Labor_19
{
    class Mains
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число:");
            int symbolInt = Int32.Parse(Console.ReadLine());
            MyFuncs.PrintSymbol(symbolInt);

            Console.WriteLine("\nВведите числa:");
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            WriteLine(MyFun.Add(a,b));
        }
    }
    class MyFuncs
    {
        public static void PrintSymbol<T> (T symbol)
        {
            for (var i = 0; i < 10; i++)
            {
                Console.Write($"{symbol} ");
            }
        }
    }

    // задание 1
    class MyFun
    {
        public static int Add(int i, int j)
        {
            int sum = i + j;
            return sum;
        }
    }
}