﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labor_19
{
    class MyFuncsLab3
    {
        public void PrintSymbol <T>(T symbol)
        {
            for (var i = 0;  i < 10; i++)
            {
                Console.WriteLine(symbol);
            }
        }
    }
}
