﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labor_6
{
    class Mains
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число");
            int N = Int32.Parse(Console.ReadLine());
            for (int i = 0; i <= N; i++)
            {
                Console.Write($" {i}");
            }

            // Задание 1
            Console.WriteLine("\nЗадание 1");
                for (int j = -3; j <= 24;j += 3)
                {
                    Console.Write($" {j}");
                }
            // Задание 2
            Console.WriteLine("\nЗадание 2");
            for (int a = 0 ;a <= 100;a++)
            {
                Console.Write($" {a}");
            }
            for(int a1 = 100; a1 >= 0; a1--)
            {
                Console.Write($" {a1}");
            }
            // Задание 3
            Console.WriteLine("\nЗадание 3");
            int plus = 0;
            int minus = 0;

            Console.WriteLine("\nВведите 10 чисел");
            for (int a = 0 ; a < 10; a++)
            {
                int numb = Int32.Parse(Console.ReadLine());
                if (numb > 0)
                {
                    plus++;
                }
                else if (numb < 0)
                {
                    minus++;
                }
            }
                Console.WriteLine("Положительных " + plus);
                Console.WriteLine("Отрицательных " + minus);

            //Задача 4
            Console.WriteLine("\nЗадание 4");
            int s = 0;
            Console.WriteLine("\nВведите 10 чисел");
            for (int a = 0; a < 10; a++)
            {
                int nums = Int32.Parse(Console.ReadLine());
                s += nums;
            }
            Console.WriteLine("Сумма " + s);

            // Задание 5 
            Console.WriteLine("\nЗадание 5");
            int sum = 0;

            Console.WriteLine("\nВведите 10 чисел");
            for (int f = 1;f <= 19; f+= 2)
            {
                Console.Write($" {f} ");
                sum += f;
                
            }
            Console.WriteLine(sum);
        }
    }
}
/*
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labor_6
{
    class Mains
    {
        static void Main(string[] args)
        {
           
        }
    }
}
*/