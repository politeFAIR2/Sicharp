﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Math;

namespace Labor_14
{
    class Mains
    {
        private static void MinmaxSeq(ref int max, ref int min)
        {
            WriteLine("Ввести последовательность и закончить 0");

            int a;
            do
            {
                a = Int32.Parse(Console.ReadLine());
                if (a > max && a != 0) { max = a;}
                if (a < min && a != 0) { min = a;}
            }
            while (a != 0); { }
        }

        static void Main(string[] args)
        {
            int min = int.MaxValue; 
            int max = int.MinValue;
            MinmaxSeq(ref max, ref min);
            WriteLine($"min is: {min}, max is {max}");

            WriteLine($"Ввести последовательность и закончить 0");
            int counterPositive = 0;
            int counterNegative = 0;
            PosNegSeq(ref counterPositive, ref counterNegative);
            WriteLine($"Положительных = {counterPositive}, отрицательных = {counterNegative}");
        }

        static void PosNegSeq(ref int CounterPositive, ref int counterNegative)
        {
            int a;
            do
            {
                a = Int32.Parse(Console.ReadLine());
                if (a > 0 && a != 0) { CounterPositive += 1; }
                if (a < 0 && a != 0) { counterNegative += 1; }
            }
            while (a != 0); { }
        }
    }
}