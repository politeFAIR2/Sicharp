﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labor_3
{
    class Mains
    {
       static void Main(string[] args)
        {
            Console.WriteLine("Введите три числа");
            string[] num = Console.ReadLine().Split(' ');
            double a = Convert.ToDouble(num[0]);
            double b = Convert.ToDouble(num[1]);
            double c = Convert.ToDouble(num[2]);

            bool res = a < b && b < c;
            Console.WriteLine(res);

            //Задание 4
            Console.WriteLine("Введите 4 числа");
            string[] num2 = Console.ReadLine().Split(' ');
            int x1 = Convert.ToInt32(num2[0]);
            int x2 = Convert.ToInt32(num2[1]);
            int x3 = Convert.ToInt32(num2[2]);
            int x4 = Convert.ToInt32(num2[3]);

            Console.WriteLine($"{(x1 + x2) > (x3 + x4)}");
        }
    }
}