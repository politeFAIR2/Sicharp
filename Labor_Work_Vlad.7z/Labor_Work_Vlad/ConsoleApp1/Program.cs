﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // 1. Вычислить дату следующего дня
        Console.WriteLine("Введите сегодняшнюю дату (число, месяц, год):");
        int day = int.Parse(Console.ReadLine());
        int month = int.Parse(Console.ReadLine());
        int year = int.Parse(Console.ReadLine());
        DateTime today = new DateTime(year, month, day);
        DateTime tomorrow = today.AddDays(1);
        Console.WriteLine("Завтра: " + tomorrow.ToShortDateString());

        // 2. Проверить, является ли год високосным
        if (DateTime.IsLeapYear(year))
        {
            Console.WriteLine("Год является високосным.");
        }
        else
        {
            Console.WriteLine("Год не является високосным.");
        }

        // 3. Запросить у пользователя номер дня недели и вывести сообщение о рабочем дне или выходном
        Console.WriteLine("Введите номер дня недели (1 - понедельник, 7 - воскресенье):");
        int dayOfWeek = int.Parse(Console.ReadLine());
        if (dayOfWeek == 6 || dayOfWeek == 7)
        {
            Console.WriteLine("Это выходной день.");
        }
        else
        {
            Console.WriteLine("Это рабочий день.");
        }

        // 4. Вычислить оптимальную массу
        Console.WriteLine("Введите ваш рост (в см):");
        int height = int.Parse(Console.ReadLine());
        Console.WriteLine("Введите ваш вес (в кг):");
        double weight = double.Parse(Console.ReadLine());
        double optimalWeight = (height - 100) * 0.9;
        if (weight > optimalWeight)
        {
            Console.WriteLine("Вам необходимо похудеть на " + (weight - optimalWeight).ToString("F1") + " кг.");
        }
        else if (weight < optimalWeight)
        {
            Console.WriteLine("Вам необходимо поправиться на " + (optimalWeight - weight).ToString("F1") + " кг.");
        }
        else
        {
            Console.WriteLine("Ваш вес оптимален.");
        }

        // 5. Вычислить стоимость разговора по телефону с учетом скидки
        Console.WriteLine("Введите количество минут разговора:");
        int minutes = int.Parse(Console.ReadLine());
        Console.WriteLine("Введите день недели (1 - понедельник, 7 - воскресенье):");
        int dayOfWeek2 = int.Parse(Console.ReadLine());
        double callCost = minutes * 3.0;
        if (dayOfWeek2 == 6 || dayOfWeek2 == 7)
        {
            callCost *= 0.85;
        }
        Console.WriteLine("Стоимость разговора: " + callCost.ToString("C"));

        // 6. Найти сумму двух чисел, если оба четные, или произведение, если хотя бы одно нечетное
        Console.WriteLine("Введите первое число:");
        int num1 = int.Parse(Console.ReadLine());
        Console.WriteLine("Введите второе число:");
        int num2 = int.Parse(Console.ReadLine());
        if (num1 % 2 == 0 && num2 % 2 == 0)
        {
            int sum = num1 + num2;
            Console.WriteLine("Сумма чисел: " + sum);
        }
        else
        {
            int product = num1 * num2;
            Console.WriteLine("Произведение чисел: " + product);
        }

        // 7. Перевести время в секундах в минуты и секунды
        Console.WriteLine("Введите время в секундах:");
        int seconds = int.Parse(Console.ReadLine());
        int minutes2 = seconds / 60;
        int remainingSeconds = seconds % 60;
        Console.WriteLine("Время: " + minutes2 + " мин " + remainingSeconds + " с");