﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Labor_8
{
    class Mains
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число");
            Int32 N = Int32.Parse(Console.ReadLine());
            int counter = 1;
            while (counter <= N) 
            {
                Console.WriteLine(counter);
                counter++;
            }
        }
    }
}