﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Math;

namespace Labor_18
{
    class Mains
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число:");
            int symbolInt = Int32.Parse(Console.ReadLine());
            PrintSymbol(symbolInt);

            Console.WriteLine("\nВведите символ:");
            string symbolStr = Console.ReadLine();
            PrintSymbol(symbolStr);
        }
        static void PrintSymbol <T> (T symbol)
        {
            for (var i=0; i < 10;  i++)
            {
                Console.Write($"{symbol} ");
            }
        }
    }
}