﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Labor_13
{
    class Mains
    { 
        static void MinMax(ref int a, ref int b)
        {
            int max = Math.Max(a, b);
            int min = Math.Min(a, b);
            a = max;
            b = min;
        }

        static void MinMax(ref int a, ref int b, ref int c)
        {
            MinMax(ref a, ref b);
            MinMax(ref b, ref c);
            MinMax(ref a, ref b);
        }

        static void ChargeDigits(ref int a1)
        {
            int ten = a1 / 10;
            int one = a1 % 10;
            a1 = one * 10 + ten; 
            Console.WriteLine($"После {a1}");
        }

        static int BitwiseSum(int a, int b)
        {
            int res = ((a / 10) + (b / 10)) * 10;
            int res1 = ((a % 10) + (b % 10)) % 10;
            res = res + res1;
            return res;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Введите два числа");
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());

            MinMax(ref a, ref b);
            Console.WriteLine($"После {a}, {b}");

            Console.WriteLine("Введите 3 числа");
            a = int.Parse(Console.ReadLine());
            b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());

            MinMax(ref a, ref b, ref c);
            Console.WriteLine($"После {a}, {b}, {c}");

            Console.WriteLine("Введите двухзначное число");
            int a1 = int.Parse(Console.ReadLine());
            ChargeDigits(ref a1);
           
            Console.WriteLine("Введите 2 двухзначных числел");
            int a2 = int.Parse(Console.ReadLine());
            int b2 = int.Parse(Console.ReadLine());

            double res1 = BitwiseSum(a2, b2);
            Console.WriteLine($"побитная сумма {res1}");
        }
       

    }
}