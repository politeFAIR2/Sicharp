﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Labor_9
{
    class Mains
    {
        static void Main(string[] args)
        {
            int counter = 1;
            do
            {
                Console.WriteLine(counter);
                counter++;
            }
            while (counter <= 5); { }

            // Задание 1
            int counter1 = 3;
            int counter2 = 3;
            Console.WriteLine("Последовательность с использованием while:");

            while (counter1 <= 21)
            {
                Console.WriteLine(counter1);
                counter1 += 2;
            }

            Console.WriteLine("Последовательность с использованием do..while:");

            do
            {
                Console.WriteLine(counter2);
                counter2 += 2;
            }
            while (counter2 <= 21);

            // Задание 2
            int a1 = 15;
            int a2 = 15;
            Console.WriteLine("Последовательность с использованием while:");

            while (a1 >= 0)
            {
                Console.WriteLine(a1);
                a1 -= 3;
            }
            Console.WriteLine("Последовательность с использованием do..while:");
            do
            {
                Console.WriteLine(a2);
                a2 -= 3;
            }
            while (a2 >= 0); { }
            Console.WriteLine("Последовательность с использованием do..while:");

            // Задание 3
            int product = 10;
            int pr = 1;
            while (product <= 20) 
            {  
                Console.Write($"{product} * "); 
                pr = pr * product;
                product += 2;
            }
            Console.Write("= " + pr);
        }
    }
}