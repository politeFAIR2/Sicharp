﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labor_6
{
    class Mains
    {
        static void Main(string[] args)
        {
            int outer;
            int inner;
            for (outer = 2; outer < 100; outer++)
            {
                for (inner = 2; inner <= (outer / 2); inner++)
                {
                    if ((outer % inner) == 0) break;
                }

                if (inner > (outer / inner))
                {
                    Console.WriteLine(($"{outer} is prime"));
                }
            }

            // Zadanie 7
            double x;
            double y;
            for (x = 2; x <= 8; x++)
            {
                for (y = 2; y <= 5; y++)
                {
                    Console.Write($"{Math.Pow(x, y)} ");
                }
            }

            // Zadanie 8
            Console.WriteLine(" ");
            double x1;
            double y1;
            for (x1 = 30; x1 <= 33; x1++)
            {
                for (y1 = 1; y1 <= 5; y1++)
                {
                    Console.Write($"{x1} - {y1} = {x1 - y1} ");
                }
            }
        }
    }
}