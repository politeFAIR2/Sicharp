﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labor_Work_Vlad
{
    internal class HW
    {
        static void Main(string[] args)
        {
            // Задания я засунул в лабы т.к проще
            Console.WriteLine("Hello mir");


            Console.WriteLine("Информация о студенте:");

            Console.Write("Имя ");
            string N = Console.ReadLine();

            Console.Write("Фамилия ");
            string F = Console.ReadLine();

            Console.Write("Дата рождения ");
            string D = Console.ReadLine();

            Console.Write("Адрес ");
            string A = Console.ReadLine();

            Console.Write("Пол ");
            char P = Convert.ToChar(Console.ReadLine());

            Console.Write("Страна ");
            string S = Console.ReadLine();

         
            Console.WriteLine("Информация о курсе:");

            Console.Write("Название курса ");
            string NC = Console.ReadLine();

            Console.Write("Баллы ");
            string B = Console.ReadLine();

            Console.Write("Количество занятий в неделю ");
            string CZ = Console.ReadLine();

            Console.Write("Преподаватель ");
            string Prep = Console.ReadLine();
            Console.WriteLine("Имя: " + N + " Фамилия: " + F + " Дата рождения: " + D + " Адрес: " + A +
                " Пол: " + P + " Страна: " + S);
            Console.WriteLine("Название курса: " + NC + " Баллы: " + B +
                " Количество занятий в неделю: " + CZ + " Пркподаватель: " + Prep);
        }
    }
}
