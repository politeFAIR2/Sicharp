﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace lab
{/*
    internal class num3
    {
        static void Main(string[] args)
        {

            //1
            Console.WriteLine("Задание 1");
            Console.WriteLine("Введите сколько элементов надо вывести: ");
             int a = int.Parse(Console.ReadLine());
             int  c = -6;
             for (int i = 0; i < a; i++) 
            {
                 c += 3;
                 Console.Write(" "+c+" "); 
            }
            Console.WriteLine("  ");
            //2

            Console.WriteLine("Задание 2");
            for (int i = 1; i < 101; i++) { 

                 Console.Write(" " + i + " ");
             }
             for (int i = 99; i > 0; i--)
             {

                 Console.Write(" "+i+" ");
              
            }
            Console.WriteLine("  ");
            //3

            Console.WriteLine("Задание 3");
            Console.WriteLine("Введите 10 целых чисел:");


            double f = 0;
            double j = 0;


            for (int i = 0; i < 10; i++)

            {
                int n = Int32.Parse(Console.ReadLine());

                if (n > 0)
                {
                    f++;
                }
                else if (n < 0)
                {
                    j++;
                }
            }

            Console.WriteLine("Количество положительных чисел:" + f);
            Console.WriteLine("Количество отрицательных чисел:" + j);
            Console.WriteLine("  ");
            //4

            Console.WriteLine("Задание 4");
            Console.WriteLine("Введите 10 целых чисел:");

            double w = 0;


            for (int i = 0; i < 10; i++)

            {
                int n = Int32.Parse(Console.ReadLine());

                w += n;
                
            }
            Console.WriteLine("Сумма чисел:" + w);
        }

    }*/
}
