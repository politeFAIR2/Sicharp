﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab
{
    internal class num4
    {/*

        static void Main(string[] args)
        {
            //1
            Console.WriteLine("Задание 1");
            int n = 3;
        do 
            {
                n += 2;

                Console.Write(n + " ");
            }
            while (n <= 21) ;
            Console.WriteLine();

            int n2 = 3;
            while (n2 <= 21) 
            {
                n2 += 2;

                Console.Write(n2 + " ");
            }
            Console.WriteLine();
            //2
            Console.WriteLine("Задание 2");
            int n3 = 15;
            while (n3 >= 0)
            {
                Console.Write(n3 + " ");
                n3 -= 3;
            }
            Console.WriteLine();

          
            int n4 = 15;
            do
            {
                Console.Write(n4 + " ");
                n4 -= 3;
            } while (n4 >= 0);
            Console.WriteLine();
            //3
            Console.WriteLine("Задание 3");
            int a = 1;
            int n5 = 10;
            while (n5 <= 20)
            {
                if (n5% 2 == 0)
                {
                    a *= n5;
                }
                n5 += 2;
            }
            Console.WriteLine("Умножение чисел 10 12 14 16 18 20: " + a);
            //4
            Console.WriteLine("Задание 4");
            double s = 0;
            double i = 0;
            while (i < 5)
            {
                Console.Write("Введите число: ");
                double n6 = Double.Parse(Console.ReadLine());
              s += n6;
                i++;
            }
            Console.WriteLine("Сумма введенных чисел: " + s);
        }*/
    }
}
