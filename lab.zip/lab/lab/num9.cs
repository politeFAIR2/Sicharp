﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static lab.MyFuncs;
using static System.Console;
namespace lab
{
    internal class num9
    {/*
        static void Main()
        {//1
            
            int[] A = { 1, 6, 2, 7, 5 };
            double[] D = { 1.2, 6.4, 2.1, 7.5, 8.1 };

            WriteLine("Целочисленный массив:");
            MyFuncs.Print(A);
            WriteLine("Элементы с четными индексами:");
            A.PrintEvenIndexes();

            WriteLine("\nМассив вещественный:");
            MyFuncs.Print(D);
            WriteLine("Элементы с четными индексами:");

            D.PrintEvenIndexes();
            //2
            Minimum minimum = new Minimum();

         
            int[] result1 = minimum.FindMin(5, 3, 6);
            Console.WriteLine("Результат с тремя параметрами (5, 3, 6):");
            foreach (var i in result1)
            {
                Console.WriteLine(i);
            }

            int[] result2 = minimum.FindMin(5, 3, 3, 6, 5);
            Console.WriteLine("\nРезультат с целочисленным массивом (5, 3, 3, 6, 5):");
            foreach (var i in result2)
            {
                Console.WriteLine(i);
            }
        }
    }
    //1
    public static class MyFuncs
    {

        public static void Print<T>(T[] arr)
        {
            foreach (var item in arr)
            {
                Write(item + " ");
            }
            WriteLine();
        }
        public static void PrintEvenIndexes<T>(this T[] arr)
        {
            for (int i = 0; i < arr.Length; i += 2)
            {
                Write(arr[i] + " ");
            }
            WriteLine();
        }
        //2
        public class Minimum
        {
            public int[] FindMin(params int[] numbers)
            {
               
                int min = int.MaxValue;
                foreach (var number in numbers)
                {
                    if (number < min)
                    {
                        min = number;
                    }
                }

               
                for (int i = 0; i < numbers.Length; i++)
                {
                    if (numbers[i] == min)
                    {
                        numbers[i] = 0;
                    }
                }

                return numbers;
            }
        }*/

    }
}
