﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace lab
{
    class num1
    { 
       /* static void Main(string[] args)
        {
            //1
            Console.WriteLine("Задание 1");
            Console.WriteLine("Имя ");
            String s = Console.ReadLine();
            Console.WriteLine("Фамилия ");
            String s1 = Console.ReadLine();
            Console.WriteLine("Дата рождения ");
            String s2 = Console.ReadLine();
            Console.WriteLine("Адрес ");
            String s3 = Console.ReadLine();
            Console.WriteLine("Пол ");
            String s4 = Console.ReadLine();
            Console.WriteLine("Страна ");
            String s5 = Console.ReadLine();
            Console.WriteLine("Название курса ");
            String s6 = Console.ReadLine();
            Console.WriteLine("Баллы ");
            String s7 = Console.ReadLine();
            Console.WriteLine("Кол-во занятий ");
            String s8 = Console.ReadLine();
            Console.WriteLine("Преподаватель ");
            String s9 = Console.ReadLine();
            Console.WriteLine(" Информация о студенте: ");
            Console.WriteLine(" Имя : "+ s + ", Фамилия : " +s1+ ", Дата рождения : "+ s2 +",");
            Console.WriteLine(" Адрес: "+s3 + ", Пол : "+s4 + ", Страна : "+s5);
            Console.WriteLine(" Информация о курсе : ");
            Console.WriteLine(" Название курса :" +s6+ ", Баллы: " + s7+", Количество занятий в неделю: "+s8 + ", Преподаватель:  "+s9);
            Console.WriteLine("  ");
            Console.WriteLine("  ");
            Console.WriteLine("  ");

            //2
            Console.WriteLine("Задание 2");
            Console.WriteLine("Введите два числа:");
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
              double n = (a + b) / 2.0;
            Console.WriteLine("Среднее арифметическое:");
            Console.WriteLine(n);
            Console.ReadLine();
            Console.ReadKey();

            //3
            Console.WriteLine("Задание 3");
            Console.WriteLine(" Введите сторону треугольника, пожалуйста: ");
            int a1 = int.Parse(Console.ReadLine());
            double t = (a1 + a1 + a1);
            double t2 =  ((a1 * a1) * Math.Sqrt(3)) / 4;
            Console.WriteLine("Периметр треугольника: " + t);
            
            Console.WriteLine(" Площадь: " + t2);

            //4
            Console.WriteLine("Задание 4");
            Console.WriteLine("Введите 4 числа:");
            int a2 = int.Parse(Console.ReadLine());
            int b2 = int.Parse(Console.ReadLine());
            int c2 = int.Parse(Console.ReadLine());
            int d2 = int.Parse(Console.ReadLine());
          
            Console.WriteLine($" a < b < c < d = { a2 < b2 && b2 < c2 && c2 < d2}"  );
      
        }*/
    }
}
