﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab
{/*
    class num2
    {
        static void Main(string[] args)

        {
            //1
            Console.WriteLine("Задание 1");
            Console.WriteLine("Введите число :");
            int a1 = int.Parse(Console.ReadLine());
            if (a1 > 0)
            {
                Console.WriteLine("Результат: введенное число положительное");
            }
            else if (a1 == 0) 
            { 
                Console.WriteLine("Результат: введенное число равно нулю");
            }
            else
            {
                Console.WriteLine("Результат: введенное число отрицательное");
            }

            //2
            Console.WriteLine("Задание 2");
            Console.WriteLine("Введите число :");

             int a2 = Convert.ToInt32(Console.ReadLine());
             int a3 = Math.Abs(a2);
             int n = a3 % 10;
             int n1 = (a3 - n) / 10;
             Console.WriteLine("Результат: "+ " единицы "+n+","+" десятки "+ n1);

            //3
            Console.WriteLine("Задание 3");
            Console.WriteLine("Введите число :");
            int a4 = int.Parse(Console.ReadLine());
            int n2 = a4 % 100;
            int n3 = a4 - n2;
            int n4 = n2 % 10;
            int n5 = n2 - n4;
            int n6 = n3 / 100;
            int n7 = n5 / 10;
            int n8 = (n6 * 100)+(n7 * 0)+(n4 * 1);
      

            Console.WriteLine("Результат "+n6+","+n7+","+n4+";"+"Результат: "+n8);
            //4
            Console.WriteLine("Задание 4");
            Console.WriteLine("Введите три числа: ");
            int b2 = int.Parse(Console.ReadLine());
            int c2 = int.Parse(Console.ReadLine());
            int d2 = int.Parse(Console.ReadLine());
            Console.WriteLine(b2 != c2 || c2 != d2 || d2 != b2  ) ;
            
        }
       

    }*/
}
