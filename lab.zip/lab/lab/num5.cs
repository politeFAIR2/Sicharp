﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab
{
    internal class num5
    {/*
        static void Main(string[] args) {
            //1
            Console.WriteLine("Задание 1");
            int p;
             Console.WriteLine("Введите три числа:");
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());


              Perimeter(a, b, c,out p);

            Console.WriteLine("Периметр: " + p);
            static void Perimeter(int a, int b, int c, out int P)
        {
             P = a + b + c;
          
        }
            //2
            Console.WriteLine("Задание 2");
            Console.WriteLine("Введите три числа:");
            int a1 = int.Parse(Console.ReadLine());
            int b1 = int.Parse(Console.ReadLine());
            int c1 = int.Parse(Console.ReadLine());


            int P1 = Perimeter2(a, b, c);

            Console.WriteLine("Периметр: " + P1);
            static int Perimeter2(int a, int b, int c)
            {
                int P = a + b + c;
                return P;
            }
            //3
            Console.WriteLine("Задание 3");
            double p2;
            Console.WriteLine("Введите четыре числа x1,y1 и x2,y2:");
            int x1= int.Parse(Console.ReadLine());
            int y1 = int.Parse(Console.ReadLine());
            int x2 = int.Parse(Console.ReadLine());
            int y2 = int.Parse(Console.ReadLine());
            Distance(x1 , x2, y1 , y2, out p2);
            Console.WriteLine("Растояние: "+p2);

            static void Distance(double x2, double x1, double y2, double y1,out double p2)
            {
               p2 = Math.Sqrt(Math.Pow(x2-x1,2)+ Math.Pow(y2 - y1, 2));
            }
            Console.WriteLine("Задание 4");
            double p3;
            Console.WriteLine("Введите четыре числа x1,y1 и x2,y2:");
            double x4 = double.Parse(Console.ReadLine());
            double y4 = double.Parse(Console.ReadLine());
            double x3 = double.Parse(Console.ReadLine());
            double y3 = double.Parse(Console.ReadLine());
            Distance2(x3, x4, y3, y4, out p3);
            Console.WriteLine("Растояние: " + p3);

            static double Distance2(double x4, double x3, double y4, double y3, out double p3)
            {
                p3 = Math.Sqrt(Math.Pow(x4 - x3, 2) + Math.Pow(y4 - y3, 2));
                return p3;
            }
        }*/
    }
}
