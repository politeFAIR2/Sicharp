﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab
{
    internal class num10
    {/*
        static void Main()
        {
            Console.WriteLine("Задание 1");
            int[,] t = {
            {-8, -14, -19, -18},
            {25, 28, 26, 20},
            {11, 18, 20, 25}
        };

            Console.WriteLine("1-е задание: {0} and {1}", t[1, 3], t[2, 0]);

            
            Console.Write("2-е задание: ");
            for (int st = 0; st < t.GetLength(0); st++)
            {
                Console.Write(t[st, 1] + " ");
            }
            Console.WriteLine();

           
            Console.WriteLine("3-е задание:");
            for (int st = 0; st < t.GetLength(0); st++)
            {
                for (int d = 0; d < t.GetLength(1); d++)
                {
                    Console.Write(t[st, d] + " ");
                }
                Console.WriteLine();
            }

           
            int s = 0;
            for (int d = 0; d < t.GetLength(1); d++)
            {
                s += t[2, d];
            }
            double a = (double)s / t.GetLength(1);
            Console.WriteLine("4-е задание: {0}", a);

            
            for (int st = 0; st < t.GetLength(0); st++)
            {
                for (int d = 0; d < t.GetLength(1); d++)
                {
                    if (t[st, d] >= 24 && t[st, d] <= 26)
                    {
                        Console.WriteLine("станция {0} день {1}", st + 1, d);
                    }
                }
            }
           

            int[,] a1 = new int[2, 3];
            int s1 = 0;
            Console.WriteLine("Задание 2");
            Console.WriteLine("Введите 6 значений для матрицы 2 х 3");

            
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    a1[i, j] = int.Parse(Console.ReadLine());
                    s1 += a1[i, j]; 
                }
            }

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write(a1[i, j] + " ");
                }
                Console.WriteLine();
            }

           
            Console.WriteLine("Сумма = " + s1);

        }*/

    }
}
