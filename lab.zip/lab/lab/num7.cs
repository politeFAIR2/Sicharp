﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace lab
{
    internal class num7
    {
        /*
        static void Main(string[] args)
            //1
        {
            int index;
            int found;
            Console.WriteLine("Задание 1");
            double[] b = { 1.1, -2.3, 3.7, 4.1, 5.6, 6.1, 7.1 };
           
            static void print(double[] b)
            {
                
                WriteLine("Массив: ");
                foreach (var x in b)
                
                    Write(x + "   ");
                WriteLine("  ");
                
            }
            static double FindMaxMin(double[] b,ref double max , ref double min)
            {
                foreach (var num in b)
                {
                    if (num > max)
                    {
                        max = num;
                    }
                    if (num < min)
                    {
                        min = num;
                    }
                }
            
              return max;
            }
            double max = double.MinValue;
            double min = double.MaxValue;
            FindMaxMin(b, ref max, ref min);
            print(b);
            WriteLine($"максимальный элемент: {max}, минимальный элемент: {min}");
            //2
            WriteLine("Задание 2");

            int[] d = new int[10];
            WriteLine("Введите искомое значение:");
            int N = int.Parse(ReadLine());

            static void FindN(int[] d, int N)
            {
                bool found = false;


                foreach (int x in d)
                {
                    if (x == N)
                    {
                        found = true;
                        break; 
                    }
                }

                if (found)
                {
                    WriteLine("  ");
                    WriteLine("результат: да");
                }
                else
                {
                    WriteLine("  ");
                    WriteLine("результат: нет");
                }
            }


            FRA(d, 1, 10);
            printarray(d);
            FindN(d, N);
        }
            static void printarray(int[] d)
            {
                for (int i = 0; i < d.Length; i++)
                {
                    Write(d[i]+" ");
                }
            }
            static void FRA(int[] d , int minValue=1 ,int maxValue=10)
            {
                Random rand = new Random();
                for(int i = 0; i < d.Length; i++)
                {
                    d[i] = rand.Next(minValue,maxValue);
                }
          
           
      
        }*/
    }
   
          



      
}
          


           
     