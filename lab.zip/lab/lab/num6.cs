﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab
{
    internal class num6
    {
        /*static void Main(string[] args)
        {
            //2
            Console.WriteLine("Задание 2");
            Console.WriteLine("Введите N и a числа:");
            int N = int.Parse(Console.ReadLine());
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Результат: ");
            IEnumerable<int> s;
            s = System.Linq.Enumerable.Range(N, a);
            foreach (var x in s)
            {
                Console.Write($" {x} ");
            }

            //3
           
            Console.WriteLine("  ");
            Console.WriteLine("Задание 3");
            IEnumerable<int> s1;
            IEnumerable<int> s2;
            s1 = System.Linq.Enumerable.Range(-5,5);
           
            foreach (var x in s1)
            {
                Console.Write(x + " ");
            }
            s2 = System.Linq.Enumerable.Range(0, 6);
            foreach (var x in s2)
            {
                Console.Write(x +" ");
            }
            s1 = System.Linq.Enumerable.Range(-5, 5);
            s1 = s1.Where(x => x % 2 == 0);
          
            Console.WriteLine("  ");
            Console.WriteLine("чёт");
            foreach (int num in s1)
            {
                Console.Write( num + " ");
            }
            s2 = System.Linq.Enumerable.Range(0, 6);
            s2 = s2.Where(x => x % 2 == 0);
            foreach (int num in s2)
            {
                Console.Write(num + " ");
            }

            s1 = System.Linq.Enumerable.Range(-5, 5);
         
            s1 = s1.Where(x => x % 5 == 0);
            Console.WriteLine("  ");
            Console.WriteLine("на 5");
            foreach (int num2 in s1)
            {
                Console.Write(  num2 + " ");
            }
            s2 = System.Linq.Enumerable.Range(0, 6);
            s2 = s2.Where(x => x % 5 == 0);
            foreach (int num2 in s2)
            {
                Console.Write(num2 + " ");
            }

            s1 = System.Linq.Enumerable.Range(-5, 5);
      
            s1 = s1.Where(x => x % 2 != 0);
            Console.WriteLine("  ");
            Console.WriteLine("нечёт");
            foreach (int num3 in s1)
            {
                Console.Write(num3 + " ");
            }
            s2 = System.Linq.Enumerable.Range(0, 6);
            s2 = s2.Where(x => x % 2 != 0);
            foreach (int num3 in s2)
            {
                Console.Write(num3 + " ");
            }
            Console.WriteLine("  ");
            //4
            Console.WriteLine("Задание 4");
            IEnumerable<int> s3;
            s3 = Enumerable.Range(1, 10);
            foreach (int num in s3)
            {
                Console.Write(num + " ");
            }
            Console.WriteLine("  ");
            Console.WriteLine("Результат :");
            s3 = Enumerable.Range(1, 10).Select(x => 2 + x);
            foreach (int num in s3)
            {
                Console.Write(num +" ");
            }
        }*/
    }
}
