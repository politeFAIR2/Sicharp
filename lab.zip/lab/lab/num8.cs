﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace lab
{
    internal class num8
    {/*
        static void Main()
            
        {//1
            WriteLine("Введите два числа:");
            string[] i = ReadLine().Split(' ');


            int n1 = int.Parse(i[0]);
            int n2 = int.Parse(i[1]);

            int r = MyFuncs.d(n1, n2);
            
            WriteLine("Сумма: " + r);
            //2
            int[] arr = L8F.FillRandomArray(10, -10, 10);
            L8F.print(arr);

            int evenCount;
            L8F.FindEven(arr, out evenCount);

            Console.WriteLine("Количество четных: " + evenCount);

        }
    }

    public class MyFuncs
    {//1
        public static int d(int i, int j)
        {
            return i + j;
        }
    }

    public class L8F
    {//2
        public static int[] FillRandomArray(int length, int minValue, int maxValue)
        {
            Random rand = new Random();
            int[] arr = new int[length];

            for (int i = 0; i < length; i++)
            {
                arr[i] = rand.Next(minValue, maxValue + 1);
            }

            return arr;
        }

        public static void print(int[] arr)
        {
            Console.WriteLine("Массив:");
            foreach (int num in arr)
            {
                Console.Write(num + " ");
            }
            Console.WriteLine();
        }

        public static void FindEven(int[] arr, out int counter)
        {
            counter = 0;
            Console.WriteLine("Четные элементы:");

            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] % 2 == 0)
                {
                    Console.WriteLine($"{arr[i]}, index: {i}");
                    counter++;
                }
            }
        }*/

    }
}


